using Jewel.JPMS.Models;

namespace Jewel.JPMS.Services;

/// <summary>
/// Front-end store for labour tracking (docs/Labour-Time-Tracking-Scope.md). Synchronous reads
/// follow the fetch-once-per-key convention (CLAUDE.md): pages call the Refresh methods once
/// from OnInitializedAsync so tab navigation revalidates in the background.
/// </summary>
public interface ILabourStore
{
    event Action? OnChange;

    // Registry (commercial team only — includes rates).
    IReadOnlyList<Worker> Workers();
    /// <summary>False until the registry has landed — the synchronous reads answer with empty
    /// lists in the meantime, which no view can tell apart from a real empty result.</summary>
    bool WorkersLoaded { get; }
    Task RefreshWorkersAsync();
    Task<Worker> AddWorkerAsync(string name, decimal hourlyRate, string? subcontractorId, string contactEmail, string contactPhone);
    Task<Worker> UpdateWorkerAsync(Worker worker);
    Task DeleteWorkerAsync(string workerId);

    // Project assignment.
    IReadOnlyList<ProjectWorkerAssignment> AssignmentsFor(string projectId);
    /// <summary>False until this project's assignments have landed — see <see cref="WorkersLoaded"/>.</summary>
    bool AssignmentsLoadedFor(string projectId);
    Task RefreshAssignmentsAsync(string projectId);
    Task SetAssignmentAsync(string projectId, string workerId, bool isActive);

    // My Day — the signed-in worker's own timesheet surface.
    MyLabourDay? MyDay();
    Task RefreshMyDayAsync();
    Task MySignInAsync(string projectId);
    Task MySignOutAsync(string projectId, IReadOnlyList<SiteSignOutEntry> entries);
    Task MyResubmitAsync(string timesheetId, decimal hours, string costCode);

    // Timesheets + register.
    IReadOnlyList<TimesheetDetail> TimesheetsFor(string projectId);
    /// <summary>False until this project's timesheets have landed — see <see cref="WorkersLoaded"/>.</summary>
    bool TimesheetsLoadedFor(string projectId);
    Task RefreshTimesheetsAsync(string projectId);
    IReadOnlyList<SiteAttendance> AttendanceFor(string projectId);
    /// <summary>False until this project's register has landed — see <see cref="WorkersLoaded"/>.</summary>
    bool AttendanceLoadedFor(string projectId);
    Task RefreshAttendanceAsync(string projectId);

    Task<TimesheetDetail> AddWorkerTimesheetAsync(string projectId, string workerId, DateTimeOffset workedOn, decimal hours, string costCode);
    Task<TimesheetDetail> AdjustTimesheetAsync(string projectId, string timesheetId, decimal hours, string costCode);
    Task<LabourApprovalResult> ApproveTimesheetsAsync(string projectId, IReadOnlyList<string> timesheetIds);
    Task<TimesheetDetail> RejectTimesheetAsync(string projectId, string timesheetId, string reason);

    // Settlement reconciliation.
    IReadOnlyList<LabourSettlementRow> SettlementFor(string projectId);
    /// <summary>False until this project's settlement rows have landed — see <see cref="WorkersLoaded"/>.</summary>
    bool SettlementLoadedFor(string projectId);
    Task RefreshSettlementAsync(string projectId);
    Task SetTimesheetCoverAsync(string projectId, string xeroLedgerLineId, bool isCovered, string subcontractorId, DateTimeOffset periodStart, DateTimeOffset periodEnd);
    Task AddSettlementVarianceAsync(string projectId, string costCode, string subcontractorId, decimal amount, string reason, string? xeroLedgerLineId);
}
