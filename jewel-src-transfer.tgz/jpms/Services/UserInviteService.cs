using System.Net.Http.Json;
using Jewel.JPMS.Contracts.Auth;
using Jewel.JPMS.Contracts.Subcontractors;
using Jewel.JPMS.Models;

namespace Jewel.JPMS.Services;

/// <summary>Admin-only: creates/updates a user and mints a single-use "set your password" link.</summary>
public sealed class UserInviteService
{
    private const string InviteEndpoint = "/api/auth/invite";
    private const string SendResetEndpoint = "/api/auth/send-reset";

    private readonly HttpClient httpClient;

    public UserInviteService(HttpClient httpClient)
    {
        this.httpClient = httpClient;
    }

    public sealed record InviteOutcome(bool Success, InviteResult? Result, string? Error);

    public async Task<InviteOutcome> InviteAsync(string email, string displayName, IReadOnlyList<Role> roles)
    {
        try
        {
            var request = new InviteUserRequest(email, displayName, roles);
            var response = await httpClient.PostAsJsonAsync(InviteEndpoint, request);
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<InviteResult>();
                return result is null
                    ? new InviteOutcome(false, null, "The server returned an unexpected response.")
                    : new InviteOutcome(true, result, null);
            }

            var error = await TryReadErrorAsync(response);
            return new InviteOutcome(false, null, error ?? "Couldn't create the invite. Please try again.");
        }
        catch
        {
            return new InviteOutcome(false, null, "Couldn't reach the server. Check your connection and try again.");
        }
    }

    /// <summary>
    /// Admin action: emails an existing user a single-use password-reset link, and hands the link
    /// back so it can be relayed by hand if the email does not arrive. Unlike the public
    /// "forgot password" flow this reports real failures — the caller is already an administrator,
    /// so "they've never set a password, re-invite them" is useful rather than a leak.
    /// </summary>
    public async Task<InviteOutcome> SendPasswordResetAsync(string email)
    {
        try
        {
            var response = await httpClient.PostAsJsonAsync(SendResetEndpoint, new SendPasswordResetRequest(email));
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<InviteResult>();
                return result is null
                    ? new InviteOutcome(false, null, "The server returned an unexpected response.")
                    : new InviteOutcome(true, result, null);
            }

            var error = await TryReadErrorAsync(response);
            return new InviteOutcome(false, null, error ?? "Couldn't send a reset link. Please try again.");
        }
        catch
        {
            return new InviteOutcome(false, null, "Couldn't reach the server. Check your connection and try again.");
        }
    }

    /// <summary>Invites a subcontractor's contact to the portal: mints the set-password link and
    /// links the login to the record so their session is scoped to their own company.</summary>
    public async Task<InviteOutcome> InviteSubcontractorAsync(string subcontractorId, string? email = null, string? displayName = null)
    {
        try
        {
            var request = new InviteSubcontractorPortalUserRequest(email, displayName);
            var response = await httpClient.PostAsJsonAsync(
                $"/api/subcontractors/{Uri.EscapeDataString(subcontractorId)}/portal-invite", request);
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<InviteResult>();
                return result is null
                    ? new InviteOutcome(false, null, "The server returned an unexpected response.")
                    : new InviteOutcome(true, result, null);
            }

            var error = await TryReadErrorAsync(response);
            return new InviteOutcome(false, null, error ?? "Couldn't create the portal invite. Please try again.");
        }
        catch
        {
            return new InviteOutcome(false, null, "Couldn't reach the server. Check your connection and try again.");
        }
    }

    private static async Task<string?> TryReadErrorAsync(HttpResponseMessage response)
    {
        try
        {
            var problem = await response.Content.ReadFromJsonAsync<ErrorResponse>();
            return string.IsNullOrWhiteSpace(problem?.Error) ? null : problem!.Error;
        }
        catch
        {
            return null;
        }
    }

    private sealed record ErrorResponse(string? Error);
}
