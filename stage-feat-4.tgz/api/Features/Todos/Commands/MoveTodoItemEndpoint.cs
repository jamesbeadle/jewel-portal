using Jewel.JPMS.Api.Cqrs;
using Jewel.JPMS.Api.Gates;
using Jewel.JPMS.Contracts.Todos;
using Jewel.JPMS.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;

namespace Jewel.JPMS.Api.Features.Todos.Commands;

public sealed class MoveTodoItemEndpoint
{
    private readonly SignedInUserResolver users;
    private readonly MoveTodoItemAuthorisation authorisation;
    private readonly MoveTodoItemValidation validation;
    private readonly ICommandHandler<MoveTodoItem, TodoItem> handler;

    public MoveTodoItemEndpoint(SignedInUserResolver users, MoveTodoItemAuthorisation authorisation, MoveTodoItemValidation validation, ICommandHandler<MoveTodoItem, TodoItem> handler)
    { this.users = users; this.authorisation = authorisation; this.validation = validation; this.handler = handler; }

    [Function(nameof(MoveTodoItem))]
    public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "todo-items/{todoItemId}/move")] HttpRequest request, string todoItemId)
    {
        var signedInUser = await users.ResolveAsync(request, request.HttpContext.RequestAborted);
        if (signedInUser is null) return new UnauthorizedResult();
        var command = await request.ReadFromJsonAsync<MoveTodoItem>();
        if (command is null) return new BadRequestResult();
        if (command.TodoItemId != todoItemId) return new BadRequestObjectResult("Route todoItemId does not match body.");
        if (!authorisation.Allows(signedInUser, command)) return new StatusCodeResult(403);
        var validationOutcome = validation.Check(command);
        if (validationOutcome.HasFailed) return new BadRequestObjectResult(validationOutcome.Errors);
        return new OkObjectResult(await handler.HandleAsync(command, request.HttpContext.RequestAborted));
    }
}
