using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Jewel.JPMS.Contracts.Xero;
using Microsoft.Extensions.Logging;

namespace Jewel.JPMS.Api.Features.Xero;

/// <summary>
/// Minimal client for the Xero Accounting API over a custom connection (client-credentials grant).
/// Returns a snapshot rather than throwing so the UI can explain "not configured" and "Xero said no"
/// states instead of surfacing a 500. Reads purchase invoices with line items (Xero includes line
/// items on paged /Invoices responses) plus the chart of accounts for account names, and caches the
/// assembled snapshot briefly — a multi-year read costs dozens of calls against Xero's 60/min limit.
/// </summary>
public interface IXeroClient
{
    bool IsConfigured { get; }

    /// <summary>
    /// Lists purchase invoices (ACCPAY bills) from the configured start date, newest first.
    /// Serves the cached snapshot when fresh enough unless <paramref name="force"/> is set.
    /// </summary>
    Task<XeroTransactionsSnapshot> GetPurchaseInvoicesAsync(bool force, CancellationToken ct);

    /// <summary>
    /// Reads the company's cash position: every bank account's closing balance today (Xero's
    /// bank summary report — needs the accounting.reports.read scope) plus the authorised
    /// sales invoices (ACCREC) with money still due. Serves the cached snapshot when fresh
    /// enough unless <paramref name="force"/> is set.
    /// </summary>
    Task<XeroCashSummarySnapshot> GetCashSummaryAsync(bool force, CancellationToken ct);

    /// <summary>
    /// Reads the aged payables position: every ACCPAY bill with money still due — DRAFT and
    /// SUBMITTED included, because the accounting procedure leaves bills in draft until they are
    /// coded through the portal and Xero's own aged payables report cannot see them — plus every
    /// ACCPAYCREDIT credit note with credit still unapplied. Deliberately no date floor (unlike
    /// the ledger's reporting window): an old unpaid bill still belongs on the report. Serves
    /// the cached snapshot when fresh enough unless <paramref name="force"/> is set.
    /// </summary>
    Task<XeroAgedPayablesSnapshot> GetAgedPayablesAsync(bool force, CancellationToken ct);

    /// <summary>
    /// Reads the aged receivables position: every ACCREC sales invoice with money still due —
    /// DRAFT and SUBMITTED included, mirroring the payables read, so an invoice still being
    /// prepared is visible before Xero's own aged receivables can see it — plus every
    /// ACCRECCREDIT credit note with credit still unapplied. Deliberately no date floor (unlike
    /// the ledger's reporting window): an old unpaid invoice still belongs on the report. Serves
    /// the cached snapshot when fresh enough unless <paramref name="force"/> is set.
    /// </summary>
    Task<XeroAgedReceivablesSnapshot> GetAgedReceivablesAsync(bool force, CancellationToken ct);

    /// <summary>
    /// Lists the suppliers held in Xero (contacts flagged IsSupplier), A–Z by name, for the
    /// directory's "Import from Xero" modal. Serves the cached snapshot when fresh enough unless
    /// <paramref name="force"/> is set. The AlreadyImported/LinkedSubcontractorId stamps are left
    /// at their defaults here — the query handler joins them on from the directory's Xero links.
    /// </summary>
    Task<XeroSuppliersSnapshot> GetSuppliersAsync(bool force, CancellationToken ct);

    /// <summary>
    /// Lists the organisation's tracking categories with their options exactly as Xero holds
    /// them (archived options included and flagged) — the read behind the Cost codes page's
    /// "Xero sites" / "Xero cost codes" tabs, so the exact phrasing of each option can be
    /// checked when linking projects and cost codes to Xero. Needs the custom connection's
    /// accounting.settings scope; a refusal (or a 429) comes back on the snapshot's Error
    /// rather than throwing. Serves the cached snapshot when fresh enough unless
    /// <paramref name="force"/> is set — one Xero call, but it shares the 60/min budget
    /// with everything else.
    /// </summary>
    Task<XeroTrackingCategoriesSnapshot> GetTrackingCategoriesSnapshotAsync(bool force, CancellationToken ct);

    /// <summary>
    /// Confirms an allocated draft (or submitted) bill / credit note back into Xero and
    /// approves it: re-reads the invoice fresh, stamps Sites + Cost Code tracking on each
    /// instructed line — physically splitting a line into one Xero line per cost centre
    /// when the allocation is split, amounts pro-rated so the invoice total is unchanged —
    /// then sets the status to AUTHORISED in the same update. Missing Cost Code tracking
    /// options are created in Xero; a missing Sites option fails loudly instead (sites are
    /// an explicit per-project mapping, never invented here). Returns a result rather than
    /// throwing so callers can stamp the outcome onto the stored ledger lines.
    /// </summary>
    Task<XeroApprovalResult> ApproveInvoiceAsync(XeroApprovalRequest request, CancellationToken ct);

    /// <summary>
    /// Writes the Sites tracking option onto specific line items of a draft (or
    /// submitted) bill / credit note WITHOUT approving it — the SetProject
    /// half-step, when a queued line's project is decided before its cost
    /// centre. Untargeted lines pass through untouched; targeted lines keep any
    /// other tracking (Xero's own cost code) they already carry. Returns
    /// AlreadyApproved (a silent success) when the invoice was approved outside
    /// JPMS — those keep flowing through allocation portal-side only.
    /// </summary>
    Task<XeroApprovalResult> SetSiteTrackingAsync(XeroSiteTrackingRequest request, CancellationToken ct);

    /// <summary>
    /// Lists the attachments Xero holds for one invoice or credit note — the supplier's
    /// document(s), typically published by Dext. Requires the custom connection's
    /// accounting.attachments scope; throws <see cref="XeroCallFailedException"/> (message
    /// safe to surface) when Xero refuses.
    /// </summary>
    Task<IReadOnlyList<XeroInvoiceAttachment>> ListAttachmentsAsync(
        string invoiceId, bool isCreditNote, CancellationToken ct);

    /// <summary>
    /// Streams one attachment's bytes by file name (Xero's attachment content endpoint is
    /// addressed by file name, with the Accept header naming the content type). Null when
    /// the invoice has no attachment by that name.
    /// </summary>
    Task<XeroAttachmentContent?> GetAttachmentAsync(
        string invoiceId, bool isCreditNote, string fileName, CancellationToken ct);

    /// <summary>
    /// One site's monthly P&amp;L from Xero's profit &amp; loss report filtered by the named
    /// "Sites" tracking option: income, cost of sales and operating expenses per month, first
    /// of month, oldest first, months with no movement omitted. Needs the custom connection's
    /// accounting.reports.read scope. Reads in windows of up to twelve monthly columns per
    /// call (Xero's periods cap), so a multi-year history costs a handful of calls. Throws
    /// <c>XeroCallFailedException</c> (message safe to surface) when Xero refuses or the
    /// option doesn't exist — the site mapping is explicit, so a miss is a config error to
    /// report, never something to guess around.
    /// </summary>
    Task<IReadOnlyList<XeroSitePnlMonthFigures>> GetSiteMonthlyPnlAsync(
        string siteOption, DateTime fromMonth, DateTime toMonth, CancellationToken ct);
}

/// <summary>One attachment's bytes plus the content type Xero reported for it.</summary>
public sealed record XeroAttachmentContent(byte[] Content, string ContentType, string FileName);

/// <summary>No-op used when no Xero client id/secret is configured; reports itself as such.</summary>
public sealed class NullXeroClient : IXeroClient
{
    public bool IsConfigured => false;

    public Task<XeroTransactionsSnapshot> GetPurchaseInvoicesAsync(bool force, CancellationToken ct) =>
        Task.FromResult(XeroTransactionsSnapshot.NotConfigured());

    public Task<XeroCashSummarySnapshot> GetCashSummaryAsync(bool force, CancellationToken ct) =>
        Task.FromResult(XeroCashSummarySnapshot.NotConfigured());

    public Task<XeroAgedPayablesSnapshot> GetAgedPayablesAsync(bool force, CancellationToken ct) =>
        Task.FromResult(XeroAgedPayablesSnapshot.NotConfigured());

    public Task<XeroAgedReceivablesSnapshot> GetAgedReceivablesAsync(bool force, CancellationToken ct) =>
        Task.FromResult(XeroAgedReceivablesSnapshot.NotConfigured());

    public Task<XeroTrackingCategoriesSnapshot> GetTrackingCategoriesSnapshotAsync(bool force, CancellationToken ct) =>
        Task.FromResult(XeroTrackingCategoriesSnapshot.NotConfigured());

    public Task<XeroSuppliersSnapshot> GetSuppliersAsync(bool force, CancellationToken ct) =>
        Task.FromResult(XeroSuppliersSnapshot.NotConfigured());

    public Task<XeroApprovalResult> ApproveInvoiceAsync(XeroApprovalRequest request, CancellationToken ct) =>
        Task.FromResult(XeroApprovalResult.Failed(
            "Xero isn't connected — add the Xero__ClientId / Xero__ClientSecret app settings."));

    public Task<XeroApprovalResult> SetSiteTrackingAsync(XeroSiteTrackingRequest request, CancellationToken ct) =>
        Task.FromResult(XeroApprovalResult.Failed(
            "Xero isn't connected — add the Xero__ClientId / Xero__ClientSecret app settings."));

    public Task<IReadOnlyList<XeroInvoiceAttachment>> ListAttachmentsAsync(
        string invoiceId, bool isCreditNote, CancellationToken ct) =>
        Task.FromResult<IReadOnlyList<XeroInvoiceAttachment>>(Array.Empty<XeroInvoiceAttachment>());

    public Task<XeroAttachmentContent?> GetAttachmentAsync(
        string invoiceId, bool isCreditNote, string fileName, CancellationToken ct) =>
        Task.FromResult<XeroAttachmentContent?>(null);

    public Task<IReadOnlyList<XeroSitePnlMonthFigures>> GetSiteMonthlyPnlAsync(
        string siteOption, DateTime fromMonth, DateTime toMonth, CancellationToken ct) =>
        Task.FromResult<IReadOnlyList<XeroSitePnlMonthFigures>>(Array.Empty<XeroSitePnlMonthFigures>());
}

/// <summary>REST implementation (hand-rolled HttpClient, matching the app's style — see ClaudeClient).</summary>
public sealed class XeroClient : IXeroClient
{
    private const string TokenUrl = "https://identity.xero.com/connect/token";
    private const string InvoicesUrl = "https://api.xero.com/api.xro/2.0/Invoices";
    private const string CreditNotesUrl = "https://api.xero.com/api.xro/2.0/CreditNotes";
    private const string AccountsUrl = "https://api.xero.com/api.xro/2.0/Accounts";
    private const string ContactsUrl = "https://api.xero.com/api.xro/2.0/Contacts";
    private const string BankSummaryReportUrl = "https://api.xero.com/api.xro/2.0/Reports/BankSummary";
    private const string ProfitAndLossReportUrl = "https://api.xero.com/api.xro/2.0/Reports/ProfitAndLoss";
    private const string TrackingCategoriesUrl = "https://api.xero.com/api.xro/2.0/TrackingCategories";
    private const int PageSize = 100; // Xero's page size for the Invoices endpoint.

    private readonly HttpClient _http;
    private readonly XeroOptions _options;
    private readonly ILogger<XeroClient> _logger;

    // Client-credentials tokens last ~30 minutes; cache until shortly before expiry.
    private readonly SemaphoreSlim _tokenLock = new(1, 1);
    private string? _accessToken;
    private DateTimeOffset _accessTokenExpiresAt = DateTimeOffset.MinValue;

    // Snapshot cache — one fetch serves every user for CacheMinutes. Guarded by a lock so two
    // simultaneous page loads don't both run a multi-page Xero read.
    private readonly SemaphoreSlim _snapshotLock = new(1, 1);
    private XeroTransactionsSnapshot? _cachedSnapshot;
    private DateTimeOffset _cachedSnapshotAt = DateTimeOffset.MinValue;

    // Cash summary cache — separate from the transactions snapshot (different data, same
    // rationale: one fetch serves every user for CacheMinutes).
    private readonly SemaphoreSlim _cashSummaryLock = new(1, 1);
    private XeroCashSummarySnapshot? _cachedCashSummary;
    private DateTimeOffset _cachedCashSummaryAt = DateTimeOffset.MinValue;

    // Aged payables cache — separate from the transactions snapshot (that one is windowed by
    // FromDate and carries line items; this one is outstanding-only, unwindowed and line-free).
    private readonly SemaphoreSlim _agedPayablesLock = new(1, 1);
    private XeroAgedPayablesSnapshot? _cachedAgedPayables;
    private DateTimeOffset _cachedAgedPayablesAt = DateTimeOffset.MinValue;

    // Aged receivables cache — the sales-side mirror of the payables cache above.
    private readonly SemaphoreSlim _agedReceivablesLock = new(1, 1);
    private XeroAgedReceivablesSnapshot? _cachedAgedReceivables;
    private DateTimeOffset _cachedAgedReceivablesAt = DateTimeOffset.MinValue;

    // Supplier list cache — same rationale as the snapshots above (the contact list costs several
    // paged calls against the 60/min limit, and one fetch serves every user for CacheMinutes).
    private readonly SemaphoreSlim _suppliersLock = new(1, 1);
    private XeroSuppliersSnapshot? _cachedSuppliers;
    private DateTimeOffset _cachedSuppliersAt = DateTimeOffset.MinValue;

    // Tracking-categories snapshot cache — the Cost codes page's Xero tabs. One cheap call,
    // but it counts against the same 60/min budget as everything else (the write-back reads
    // the same endpoint), so a page of users mustn't each cost a call.
    private readonly SemaphoreSlim _trackingCategoriesLock = new(1, 1);
    private XeroTrackingCategoriesSnapshot? _cachedTrackingCategories;
    private DateTimeOffset _cachedTrackingCategoriesAt = DateTimeOffset.MinValue;

    // Chart of accounts changes rarely; refresh it hourly at most.
    private IReadOnlyDictionary<string, string>? _accountNamesByCode;
    private DateTimeOffset _accountNamesFetchedAt = DateTimeOffset.MinValue;

    // Tracking categories change rarely too, and every site-P&L read and write-back needs
    // them — cached briefly so a sync over N projects costs ONE call, not N (uncached, that
    // alone can spend Xero's 60/min budget and everything after it 429s). Distinct from the
    // Cost codes page's snapshot cache above: this is the write-back/P&L lookup shape.
    private TrackingCategoryLookup? _trackingLookup;
    private DateTimeOffset _trackingLookupAt = DateTimeOffset.MinValue;

    public XeroClient(HttpClient http, XeroOptions options, ILogger<XeroClient> logger)
    {
        _http = http;
        _options = options;
        _logger = logger;
    }

    public bool IsConfigured => _options.IsConfigured;

    public async Task<XeroTransactionsSnapshot> GetPurchaseInvoicesAsync(bool force, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroTransactionsSnapshot.NotConfigured();

        await _snapshotLock.WaitAsync(ct);
        try
        {
            if (!force && CachedSnapshotIsFresh)
                return _cachedSnapshot!;

            var snapshot = await FetchSnapshotAsync(ct);

            // Only successful reads replace the cache — a transient failure shouldn't evict good data,
            // but it is still returned so the user sees what went wrong.
            if (snapshot.Error is null)
            {
                _cachedSnapshot = snapshot;
                _cachedSnapshotAt = DateTimeOffset.UtcNow;
            }
            return snapshot;
        }
        finally
        {
            _snapshotLock.Release();
        }
    }

    private bool CachedSnapshotIsFresh =>
        _cachedSnapshot is not null
        && DateTimeOffset.UtcNow < _cachedSnapshotAt.AddMinutes(_options.CacheMinutes);

    // -- cash summary: bank balances + outstanding sales invoices ----------------------

    public async Task<XeroCashSummarySnapshot> GetCashSummaryAsync(bool force, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroCashSummarySnapshot.NotConfigured();

        await _cashSummaryLock.WaitAsync(ct);
        try
        {
            if (!force && CachedCashSummaryIsFresh)
                return _cachedCashSummary!;

            var snapshot = await FetchCashSummaryAsync(ct);

            // Only successful reads replace the cache — a transient failure shouldn't evict
            // good data, but it is still returned so the user sees what went wrong.
            if (snapshot.Error is null)
            {
                _cachedCashSummary = snapshot;
                _cachedCashSummaryAt = DateTimeOffset.UtcNow;
            }
            return snapshot;
        }
        finally
        {
            _cashSummaryLock.Release();
        }
    }

    private bool CachedCashSummaryIsFresh =>
        _cachedCashSummary is not null
        && DateTimeOffset.UtcNow < _cachedCashSummaryAt.AddMinutes(_options.CacheMinutes);

    // -- aged payables: outstanding supplier bills, drafts included ---------------------

    public async Task<XeroAgedPayablesSnapshot> GetAgedPayablesAsync(bool force, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroAgedPayablesSnapshot.NotConfigured();

        await _agedPayablesLock.WaitAsync(ct);
        try
        {
            if (!force && CachedAgedPayablesAreFresh)
                return _cachedAgedPayables!;

            var snapshot = await FetchAgedPayablesAsync(ct);

            // Only successful reads replace the cache — a transient failure shouldn't evict
            // good data, but it is still returned so the user sees what went wrong.
            if (snapshot.Error is null)
            {
                _cachedAgedPayables = snapshot;
                _cachedAgedPayablesAt = DateTimeOffset.UtcNow;
            }
            return snapshot;
        }
        finally
        {
            _agedPayablesLock.Release();
        }
    }

    private bool CachedAgedPayablesAreFresh =>
        _cachedAgedPayables is not null
        && DateTimeOffset.UtcNow < _cachedAgedPayablesAt.AddMinutes(_options.CacheMinutes);

    // -- aged receivables: outstanding sales invoices, drafts included ------------------

    public async Task<XeroAgedReceivablesSnapshot> GetAgedReceivablesAsync(bool force, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroAgedReceivablesSnapshot.NotConfigured();

        await _agedReceivablesLock.WaitAsync(ct);
        try
        {
            if (!force && CachedAgedReceivablesAreFresh)
                return _cachedAgedReceivables!;

            var snapshot = await FetchAgedReceivablesAsync(ct);

            // Only successful reads replace the cache — a transient failure shouldn't evict
            // good data, but it is still returned so the user sees what went wrong.
            if (snapshot.Error is null)
            {
                _cachedAgedReceivables = snapshot;
                _cachedAgedReceivablesAt = DateTimeOffset.UtcNow;
            }
            return snapshot;
        }
        finally
        {
            _agedReceivablesLock.Release();
        }
    }

    private bool CachedAgedReceivablesAreFresh =>
        _cachedAgedReceivables is not null
        && DateTimeOffset.UtcNow < _cachedAgedReceivablesAt.AddMinutes(_options.CacheMinutes);

    // -- suppliers: the contact list behind the directory's "Import from Xero" ----------

    public async Task<XeroSuppliersSnapshot> GetSuppliersAsync(bool force, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroSuppliersSnapshot.NotConfigured();

        await _suppliersLock.WaitAsync(ct);
        try
        {
            if (!force && CachedSuppliersAreFresh)
                return _cachedSuppliers!;

            var snapshot = await FetchSuppliersAsync(ct);

            // Only successful reads replace the cache — a transient failure shouldn't evict
            // good data, but it is still returned so the user sees what went wrong.
            if (snapshot.Error is null)
            {
                _cachedSuppliers = snapshot;
                _cachedSuppliersAt = DateTimeOffset.UtcNow;
            }
            return snapshot;
        }
        finally
        {
            _suppliersLock.Release();
        }
    }

    private bool CachedSuppliersAreFresh =>
        _cachedSuppliers is not null
        && DateTimeOffset.UtcNow < _cachedSuppliersAt.AddMinutes(_options.CacheMinutes);

    private async Task<XeroSuppliersSnapshot> FetchSuppliersAsync(CancellationToken ct)
    {
        string token;
        try
        {
            token = await GetAccessTokenAsync(ct);
        }
        catch (XeroCallFailedException tokenFailure)
        {
            return XeroSuppliersSnapshot.Failed(tokenFailure.Message);
        }

        var suppliers = new List<XeroSupplier>();
        var truncated = false;
        try
        {
            // EVERY active contact, not where=IsSupplier==true: Xero only sets IsSupplier once a
            // contact has had a bill, so the filter would hide a supplier created moments ago and
            // never yet billed. The flags come back per row and the modal narrows client-side
            // (customer-only contacts hidden by default). includeArchived is deliberately not
            // sent. Paged like the invoices read.
            for (var page = 1; ; page++)
            {
                if (page > _options.MaxPages) { truncated = true; break; }

                var url = $"{ContactsUrl}?page={page}&order={Uri.EscapeDataString("Name")}";
                using var doc = await GetJsonAsync(token, url, "contacts", ct);

                if (!doc.RootElement.TryGetProperty("Contacts", out var contacts) || contacts.ValueKind != JsonValueKind.Array)
                    break;

                var pageOfSuppliers = contacts.EnumerateArray().Select(ReadSupplier).ToList();
                suppliers.AddRange(pageOfSuppliers);
                if (pageOfSuppliers.Count < PageSize) break; // Short page — no more to fetch.
            }
        }
        catch (XeroCallFailedException callFailure)
        {
            return XeroSuppliersSnapshot.Failed(callFailure.Message);
        }

        return new XeroSuppliersSnapshot(true, null, DateTimeOffset.UtcNow, truncated, suppliers);
    }

    // -- tracking categories: the Cost codes page's Xero sites / Xero cost codes tabs ---

    public async Task<XeroTrackingCategoriesSnapshot> GetTrackingCategoriesSnapshotAsync(bool force, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroTrackingCategoriesSnapshot.NotConfigured();

        await _trackingCategoriesLock.WaitAsync(ct);
        try
        {
            if (!force && CachedTrackingCategoriesAreFresh)
                return _cachedTrackingCategories!;

            var snapshot = await FetchTrackingCategoriesSnapshotAsync(ct);

            // Only successful reads replace the cache — a transient failure (429 above all)
            // shouldn't evict good data, but it is still returned so the user sees what went wrong.
            if (snapshot.Error is null)
            {
                _cachedTrackingCategories = snapshot;
                _cachedTrackingCategoriesAt = DateTimeOffset.UtcNow;
            }
            return snapshot;
        }
        finally
        {
            _trackingCategoriesLock.Release();
        }
    }

    private bool CachedTrackingCategoriesAreFresh =>
        _cachedTrackingCategories is not null
        && DateTimeOffset.UtcNow < _cachedTrackingCategoriesAt.AddMinutes(_options.CacheMinutes);

    private async Task<XeroTrackingCategoriesSnapshot> FetchTrackingCategoriesSnapshotAsync(CancellationToken ct)
    {
        string token;
        try
        {
            token = await GetAccessTokenAsync(ct);
        }
        catch (XeroCallFailedException tokenFailure)
        {
            return XeroTrackingCategoriesSnapshot.Failed(tokenFailure.Message);
        }

        try
        {
            // includeArchived: a retired option's exact name still explains historical tracking,
            // and hiding it here would make "why doesn't this match?" harder, not easier. The
            // UI flags archived rows instead. Unlike GetTrackingCategoriesAsync (the write-back's
            // lookup) this read is diagnostic: EVERY category comes back, and a missing Sites /
            // Cost Code category is the UI's message to render, not an exception.
            using var doc = await GetJsonAsync(
                token, $"{TrackingCategoriesUrl}?includeArchived=true", "tracking categories", ct);

            var categories = new List<XeroTrackingCategory>();
            if (doc.RootElement.TryGetProperty("TrackingCategories", out var trackingCategories)
                && trackingCategories.ValueKind == JsonValueKind.Array)
            {
                foreach (var category in trackingCategories.EnumerateArray())
                {
                    var name = StringOf(category, "Name");
                    var id = StringOf(category, "TrackingCategoryID");
                    if (name is null || id is null) continue;

                    var options = new List<XeroTrackingOption>();
                    if (category.TryGetProperty("Options", out var optionElements) && optionElements.ValueKind == JsonValueKind.Array)
                        foreach (var option in optionElements.EnumerateArray())
                            if (StringOf(option, "Name") is { } optionName)
                                options.Add(new XeroTrackingOption(
                                    StringOf(option, "TrackingOptionID") ?? "",
                                    optionName,
                                    StringOf(option, "Status") ?? "ACTIVE"));

                    categories.Add(new XeroTrackingCategory(
                        id,
                        name,
                        StringOf(category, "Status") ?? "ACTIVE",
                        options,
                        IsSiteCategory: Normalise(name) == Normalise(_options.SiteTrackingCategory),
                        IsCostCodeCategory: Normalise(name) == Normalise(_options.CostCodeTrackingCategory)));
                }
            }

            return new XeroTrackingCategoriesSnapshot(true, null, DateTimeOffset.UtcNow, categories);
        }
        catch (XeroCallFailedException callFailure)
        {
            return XeroTrackingCategoriesSnapshot.Failed(
                "Couldn't read Xero's tracking categories. If Xero answered 403, the custom "
                + "connection needs the accounting.settings scope; a 429 means Xero's rate "
                + "limit — wait a minute and refresh. " + callFailure.Message);
        }
    }

    private static XeroSupplier ReadSupplier(JsonElement contact) => new(
        ContactId: StringOf(contact, "ContactID") ?? Guid.NewGuid().ToString(),
        Name: StringOf(contact, "Name") ?? "",
        EmailAddress: StringOf(contact, "EmailAddress") ?? "",
        Phone: PhoneOf(contact, "DEFAULT") ?? PhoneOf(contact, "DDI") ?? "",
        Mobile: PhoneOf(contact, "MOBILE") ?? "",
        Town: AddressPartOf(contact, "City"),
        County: AddressPartOf(contact, "Region"),
        AddressLine: StreetOf(contact),
        Postcode: AddressPartOf(contact, "PostalCode"),
        ContactPersons: ReadContactPersons(contact),
        IsSupplier: BoolOf(contact, "IsSupplier"),
        IsCustomer: BoolOf(contact, "IsCustomer"));

    /// <summary>The street line(s) from the contact's first address that carries any — Xero's
    /// AddressLine1–4 joined onto one line for the directory record's AddressLine field.</summary>
    private static string StreetOf(JsonElement contact)
    {
        if (!contact.TryGetProperty("Addresses", out var addresses) || addresses.ValueKind != JsonValueKind.Array)
            return "";
        foreach (var address in addresses.EnumerateArray())
        {
            var street = string.Join(", ",
                new[] { StringOf(address, "AddressLine1"), StringOf(address, "AddressLine2"),
                        StringOf(address, "AddressLine3"), StringOf(address, "AddressLine4") }
                    .Where(part => !string.IsNullOrWhiteSpace(part)));
            if (!string.IsNullOrWhiteSpace(street)) return street;
        }
        return "";
    }

    /// <summary>One phone line by Xero PhoneType, assembled country + area + number; null when empty.</summary>
    private static string? PhoneOf(JsonElement contact, string phoneType)
    {
        if (!contact.TryGetProperty("Phones", out var phones) || phones.ValueKind != JsonValueKind.Array)
            return null;
        foreach (var phone in phones.EnumerateArray())
        {
            if (!string.Equals(StringOf(phone, "PhoneType"), phoneType, StringComparison.OrdinalIgnoreCase))
                continue;
            var number = string.Join(" ",
                new[] { StringOf(phone, "PhoneCountryCode"), StringOf(phone, "PhoneAreaCode"), StringOf(phone, "PhoneNumber") }
                    .Where(part => !string.IsNullOrWhiteSpace(part)));
            if (!string.IsNullOrWhiteSpace(number)) return number;
        }
        return null;
    }

    /// <summary>One field ("City"/"Region") from the contact's first address that carries it.</summary>
    private static string AddressPartOf(JsonElement contact, string part)
    {
        if (!contact.TryGetProperty("Addresses", out var addresses) || addresses.ValueKind != JsonValueKind.Array)
            return "";
        foreach (var address in addresses.EnumerateArray())
        {
            var value = StringOf(address, part);
            if (!string.IsNullOrWhiteSpace(value)) return value;
        }
        return "";
    }

    private static IReadOnlyList<XeroContactPerson> ReadContactPersons(JsonElement contact)
    {
        if (!contact.TryGetProperty("ContactPersons", out var persons) || persons.ValueKind != JsonValueKind.Array)
            return Array.Empty<XeroContactPerson>();
        return persons.EnumerateArray()
            .Select(person => new XeroContactPerson(
                Name: string.Join(" ",
                    new[] { StringOf(person, "FirstName"), StringOf(person, "LastName") }
                        .Where(part => !string.IsNullOrWhiteSpace(part))),
                EmailAddress: StringOf(person, "EmailAddress") ?? ""))
            .Where(person => !string.IsNullOrWhiteSpace(person.Name) || !string.IsNullOrWhiteSpace(person.EmailAddress))
            .ToList();
    }

    private async Task<XeroCashSummarySnapshot> FetchCashSummaryAsync(CancellationToken ct)
    {
        string token;
        try
        {
            token = await GetAccessTokenAsync(ct);
        }
        catch (XeroCallFailedException tokenFailure)
        {
            return XeroCashSummarySnapshot.Failed(tokenFailure.Message);
        }

        try
        {
            var bankAccounts = await FetchBankBalancesAsync(token, ct);
            var outstanding = await FetchOutstandingSalesInvoicesAsync(token, ct);
            return new XeroCashSummarySnapshot(true, null, DateTimeOffset.UtcNow, bankAccounts, outstanding);
        }
        catch (XeroCallFailedException callFailure)
        {
            return XeroCashSummarySnapshot.Failed(callFailure.Message);
        }
    }

    /// <summary>
    /// Each bank account's closing balance as of today, from Xero's bank summary report
    /// (the report is in the organisation's base currency). The report's rows carry the
    /// account name + accountID in the first cell and the closing balance in the column the
    /// header names "Closing Balance" (last column as a fallback, so a report-layout tweak
    /// degrades gracefully rather than dropping balances).
    /// </summary>
    private async Task<IReadOnlyList<XeroBankAccountBalance>> FetchBankBalancesAsync(string token, CancellationToken ct)
    {
        var today = DateTime.UtcNow.Date;
        var url = $"{BankSummaryReportUrl}?fromDate={today:yyyy-MM-dd}&toDate={today:yyyy-MM-dd}";

        JsonDocument doc;
        try
        {
            doc = await GetJsonAsync(token, url, "bank summary report", ct);
        }
        catch (XeroCallFailedException failure) when (failure.Message.Contains("HTTP 403"))
        {
            throw new XeroCallFailedException(
                "Couldn't read Xero's bank summary report — the Xero custom connection needs the "
                + "accounting.reports.read scope ticked in the Xero developer portal. " + failure.Message);
        }

        using (doc)
        {
            var balances = new List<XeroBankAccountBalance>();
            if (!doc.RootElement.TryGetProperty("Reports", out var reports)
                || reports.ValueKind != JsonValueKind.Array || reports.GetArrayLength() == 0)
                return balances;

            var closingColumn = -1;
            foreach (var row in RowsOf(reports[0]))
            {
                var rowType = StringOf(row, "RowType");
                if (rowType == "Header")
                {
                    closingColumn = FindColumn(row, "Closing Balance");
                    continue;
                }
                if (rowType != "Section") continue;

                foreach (var accountRow in RowsOf(row))
                {
                    if (StringOf(accountRow, "RowType") != "Row") continue;
                    if (!accountRow.TryGetProperty("Cells", out var cells)
                        || cells.ValueKind != JsonValueKind.Array || cells.GetArrayLength() == 0)
                        continue;

                    var nameCell = cells[0];
                    var name = StringOf(nameCell, "Value");
                    if (string.IsNullOrWhiteSpace(name)) continue;

                    var balanceIndex = closingColumn >= 0 && closingColumn < cells.GetArrayLength()
                        ? closingColumn
                        : cells.GetArrayLength() - 1;
                    balances.Add(new XeroBankAccountBalance(
                        AccountId: CellAttribute(nameCell, "accountID") ?? name,
                        Name: name,
                        Balance: CellDecimal(cells[balanceIndex])));
                }
            }
            return balances;
        }
    }

    /// <summary>Rows of a report or section — both nest them under "Rows".</summary>
    private static IEnumerable<JsonElement> RowsOf(JsonElement reportOrSection)
    {
        if (reportOrSection.TryGetProperty("Rows", out var rows) && rows.ValueKind == JsonValueKind.Array)
            foreach (var row in rows.EnumerateArray())
                yield return row;
    }

    private static int FindColumn(JsonElement headerRow, string title)
    {
        if (!headerRow.TryGetProperty("Cells", out var cells) || cells.ValueKind != JsonValueKind.Array)
            return -1;
        var index = 0;
        foreach (var cell in cells.EnumerateArray())
        {
            if (string.Equals(StringOf(cell, "Value"), title, StringComparison.OrdinalIgnoreCase))
                return index;
            index++;
        }
        return -1;
    }

    /// <summary>Report cell values arrive as strings ("12345.67"); attributes as [{ Id, Value }].</summary>
    private static decimal CellDecimal(JsonElement cell) =>
        decimal.TryParse(StringOf(cell, "Value"), System.Globalization.NumberStyles.Number,
            System.Globalization.CultureInfo.InvariantCulture, out var value)
            ? value
            : 0m;

    private static string? CellAttribute(JsonElement cell, string id)
    {
        if (!cell.TryGetProperty("Attributes", out var attributes) || attributes.ValueKind != JsonValueKind.Array)
            return null;
        foreach (var attribute in attributes.EnumerateArray())
            if (string.Equals(StringOf(attribute, "Id"), id, StringComparison.OrdinalIgnoreCase))
                return StringOf(attribute, "Value");
        return null;
    }

    /// <summary>
    /// Authorised sales invoices (ACCREC) with money still due, ordered soonest-due first.
    /// Deliberately NOT summaryOnly: Xero's lightweight mode doesn't accept the where/order
    /// parameters (the combination is an HTTP 400), and the full shape is the same paged read
    /// the purchase-side sync already uses — the line items it carries are simply ignored.
    /// AmountDue is filtered portal-side because it's a calculated field Xero's where clause
    /// doesn't index (part-paid invoices stay AUTHORISED, fully paid ones become PAID, so the
    /// filter rarely removes anything).
    /// </summary>
    private async Task<IReadOnlyList<XeroOutstandingSalesInvoice>> FetchOutstandingSalesInvoicesAsync(
        string token, CancellationToken ct)
    {
        var invoices = new List<XeroOutstandingSalesInvoice>();
        var where = "Type==\"ACCREC\" AND Status==\"AUTHORISED\"";

        for (var page = 1; page <= _options.MaxPages; page++)
        {
            var url = $"{InvoicesUrl}?page={page}"
                      + $"&where={Uri.EscapeDataString(where)}&order={Uri.EscapeDataString("DueDate ASC")}";
            using var doc = await GetJsonAsync(token, url, "sales invoices", ct);

            if (!doc.RootElement.TryGetProperty("Invoices", out var items) || items.ValueKind != JsonValueKind.Array)
                break;

            foreach (var item in items.EnumerateArray())
            {
                var amountDue = DecimalOf(item, "AmountDue");
                if (amountDue == 0m) continue;
                invoices.Add(new XeroOutstandingSalesInvoice(
                    InvoiceId: StringOf(item, "InvoiceID") ?? Guid.NewGuid().ToString(),
                    Number: StringOf(item, "InvoiceNumber"),
                    Reference: StringOf(item, "Reference"),
                    ContactName: item.TryGetProperty("Contact", out var contact) ? StringOf(contact, "Name") : null,
                    Date: DateOf(item, "DateString", "Date"),
                    DueDate: DateOf(item, "DueDateString", "DueDate"),
                    Total: DecimalOf(item, "Total"),
                    AmountDue: amountDue,
                    CurrencyCode: StringOf(item, "CurrencyCode")));
            }

            if (items.GetArrayLength() < PageSize) break; // Short page — no more to fetch.
        }

        return invoices;
    }

    private async Task<XeroAgedPayablesSnapshot> FetchAgedPayablesAsync(CancellationToken ct)
    {
        string token;
        try
        {
            token = await GetAccessTokenAsync(ct);
        }
        catch (XeroCallFailedException tokenFailure)
        {
            return XeroAgedPayablesSnapshot.Failed(tokenFailure.Message);
        }

        try
        {
            var bills = new List<XeroPayableBill>();
            // Bills first, then supplier credit notes so unapplied credit nets off the position —
            // the same pairing the ledger sync uses. Statuses are filtered in the where clause
            // (PAID and VOIDED/DELETED never belong on a payables report); AmountDue is filtered
            // portal-side because it's a calculated field Xero's where clause doesn't index.
            var truncated = await FetchOutstandingPayablesAsync(
                token, InvoicesUrl, "Invoices", "ACCPAY", "DueDate ASC", bills, ct);
            truncated |= await FetchOutstandingPayablesAsync(
                token, CreditNotesUrl, "CreditNotes", "ACCPAYCREDIT", "Date DESC", bills, ct);

            return new XeroAgedPayablesSnapshot(true, null, DateTimeOffset.UtcNow, truncated, bills);
        }
        catch (XeroCallFailedException callFailure)
        {
            return XeroAgedPayablesSnapshot.Failed(callFailure.Message);
        }
    }

    /// <summary>
    /// Pages through one collection of outstanding purchase-side documents into
    /// <paramref name="into"/>; true = page cap hit with data left. DRAFT and SUBMITTED are
    /// requested alongside AUTHORISED — the whole point of the report is the drafts Dext has
    /// published that are still being coded, which Xero's own aged payables cannot show.
    /// Deliberately NOT summaryOnly (Xero's lightweight mode rejects where/order with an HTTP
    /// 400 — see the sales-side read); the line items on the full shape are simply ignored.
    /// </summary>
    private async Task<bool> FetchOutstandingPayablesAsync(
        string token, string baseUrl, string collectionProperty, string xeroType, string order,
        List<XeroPayableBill> into, CancellationToken ct)
    {
        var where = $"Type==\"{xeroType}\" AND "
                    + "(Status==\"DRAFT\" OR Status==\"SUBMITTED\" OR Status==\"AUTHORISED\")";

        for (var page = 1; page <= _options.MaxPages; page++)
        {
            var url = $"{baseUrl}?page={page}"
                      + $"&where={Uri.EscapeDataString(where)}&order={Uri.EscapeDataString(order)}";
            using var doc = await GetJsonAsync(token, url, collectionProperty.ToLowerInvariant(), ct);

            if (!doc.RootElement.TryGetProperty(collectionProperty, out var items)
                || items.ValueKind != JsonValueKind.Array)
                return false;

            foreach (var item in items.EnumerateArray())
            {
                // AmountDue for bills, RemainingCredit for credit notes — both mean "still
                // outstanding". Zero means settled (or an empty draft): nothing to age.
                var amountDue = item.TryGetProperty("AmountDue", out _)
                    ? DecimalOf(item, "AmountDue")
                    : DecimalOf(item, "RemainingCredit");
                if (amountDue == 0m) continue;

                into.Add(new XeroPayableBill(
                    InvoiceId: StringOf(item, "InvoiceID") ?? StringOf(item, "CreditNoteID") ?? Guid.NewGuid().ToString(),
                    Type: StringOf(item, "Type") ?? xeroType,
                    Number: StringOf(item, "InvoiceNumber") ?? StringOf(item, "CreditNoteNumber"),
                    Reference: StringOf(item, "Reference"),
                    ContactName: item.TryGetProperty("Contact", out var contact) ? StringOf(contact, "Name") : null,
                    Date: DateOf(item, "DateString", "Date"),
                    DueDate: DateOf(item, "DueDateString", "DueDate"),
                    Status: StringOf(item, "Status") ?? "UNKNOWN",
                    Total: DecimalOf(item, "Total"),
                    AmountDue: amountDue,
                    CurrencyCode: StringOf(item, "CurrencyCode")));
            }

            if (items.GetArrayLength() < PageSize) return false; // Short page — no more to fetch.
        }
        return true;
    }

    private async Task<XeroAgedReceivablesSnapshot> FetchAgedReceivablesAsync(CancellationToken ct)
    {
        string token;
        try
        {
            token = await GetAccessTokenAsync(ct);
        }
        catch (XeroCallFailedException tokenFailure)
        {
            return XeroAgedReceivablesSnapshot.Failed(tokenFailure.Message);
        }

        try
        {
            var invoices = new List<XeroReceivableInvoice>();
            // Invoices first, then client credit notes so unapplied credit nets off the position —
            // mirroring the payables read. Statuses are filtered in the where clause (PAID and
            // VOIDED/DELETED never belong on a receivables report); AmountDue is filtered
            // portal-side because it's a calculated field Xero's where clause doesn't index.
            var truncated = await FetchOutstandingReceivablesAsync(
                token, InvoicesUrl, "Invoices", "ACCREC", "DueDate ASC", invoices, ct);
            truncated |= await FetchOutstandingReceivablesAsync(
                token, CreditNotesUrl, "CreditNotes", "ACCRECCREDIT", "Date DESC", invoices, ct);

            return new XeroAgedReceivablesSnapshot(true, null, DateTimeOffset.UtcNow, truncated, invoices);
        }
        catch (XeroCallFailedException callFailure)
        {
            return XeroAgedReceivablesSnapshot.Failed(callFailure.Message);
        }
    }

    /// <summary>
    /// Pages through one collection of outstanding sales-side documents into
    /// <paramref name="into"/>; true = page cap hit with data left. DRAFT and SUBMITTED are
    /// requested alongside AUTHORISED, mirroring the payables read — an invoice still being
    /// prepared is part of the honest receivables picture even though Xero's own report
    /// cannot see it. Deliberately NOT summaryOnly (Xero's lightweight mode rejects
    /// where/order with an HTTP 400 — see the sales-side read); the line items on the full
    /// shape are simply ignored.
    /// </summary>
    private async Task<bool> FetchOutstandingReceivablesAsync(
        string token, string baseUrl, string collectionProperty, string xeroType, string order,
        List<XeroReceivableInvoice> into, CancellationToken ct)
    {
        var where = $"Type==\"{xeroType}\" AND "
                    + "(Status==\"DRAFT\" OR Status==\"SUBMITTED\" OR Status==\"AUTHORISED\")";

        for (var page = 1; page <= _options.MaxPages; page++)
        {
            var url = $"{baseUrl}?page={page}"
                      + $"&where={Uri.EscapeDataString(where)}&order={Uri.EscapeDataString(order)}";
            using var doc = await GetJsonAsync(token, url, collectionProperty.ToLowerInvariant(), ct);

            if (!doc.RootElement.TryGetProperty(collectionProperty, out var items)
                || items.ValueKind != JsonValueKind.Array)
                return false;

            foreach (var item in items.EnumerateArray())
            {
                // AmountDue for invoices, RemainingCredit for credit notes — both mean "still
                // outstanding". Zero means settled (or an empty draft): nothing to age.
                var amountDue = item.TryGetProperty("AmountDue", out _)
                    ? DecimalOf(item, "AmountDue")
                    : DecimalOf(item, "RemainingCredit");
                if (amountDue == 0m) continue;

                into.Add(new XeroReceivableInvoice(
                    InvoiceId: StringOf(item, "InvoiceID") ?? StringOf(item, "CreditNoteID") ?? Guid.NewGuid().ToString(),
                    Type: StringOf(item, "Type") ?? xeroType,
                    Number: StringOf(item, "InvoiceNumber") ?? StringOf(item, "CreditNoteNumber"),
                    Reference: StringOf(item, "Reference"),
                    ContactName: item.TryGetProperty("Contact", out var contact) ? StringOf(contact, "Name") : null,
                    Date: DateOf(item, "DateString", "Date"),
                    DueDate: DateOf(item, "DueDateString", "DueDate"),
                    Status: StringOf(item, "Status") ?? "UNKNOWN",
                    Total: DecimalOf(item, "Total"),
                    AmountDue: amountDue,
                    CurrencyCode: StringOf(item, "CurrencyCode")));
            }

            if (items.GetArrayLength() < PageSize) return false; // Short page — no more to fetch.
        }
        return true;
    }

    // -- write-back: tracking confirmation + approval ---------------------------------

    public async Task<XeroApprovalResult> ApproveInvoiceAsync(XeroApprovalRequest request, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroApprovalResult.Failed(
                "Xero isn't connected — add the Xero__ClientId / Xero__ClientSecret app settings.");

        try
        {
            var token = await GetAccessTokenAsync(ct);

            var baseUrl = request.IsCreditNote ? CreditNotesUrl : InvoicesUrl;
            var collection = request.IsCreditNote ? "CreditNotes" : "Invoices";
            var idProperty = request.IsCreditNote ? "CreditNoteID" : "InvoiceID";

            // Always work from a fresh read — the stored ledger line may be minutes or
            // days old, and the update below replaces the invoice's entire line list.
            using var doc = await GetJsonAsync(token, $"{baseUrl}/{request.InvoiceId}", collection.ToLowerInvariant(), ct);
            if (!doc.RootElement.TryGetProperty(collection, out var items)
                || items.ValueKind != JsonValueKind.Array || items.GetArrayLength() == 0)
                return XeroApprovalResult.Failed("Xero returned no invoice for this id — it may have been deleted.");

            var invoice = items[0];
            var status = StringOf(invoice, "Status") ?? "UNKNOWN";
            if (status.Equals("AUTHORISED", StringComparison.OrdinalIgnoreCase)
                || status.Equals("PAID", StringComparison.OrdinalIgnoreCase))
                return XeroApprovalResult.SkippedAlreadyApproved(status);
            if (!status.Equals("DRAFT", StringComparison.OrdinalIgnoreCase)
                && !status.Equals("SUBMITTED", StringComparison.OrdinalIgnoreCase))
                return XeroApprovalResult.Failed($"The invoice is {status} in Xero and can't be approved.");

            var categories = await GetTrackingCategoriesAsync(token, ct);

            // Sites are an explicit per-project mapping — a missing option means the
            // mapping is wrong (or the option was renamed in Xero), so fail loudly.
            var missingSites = request.Lines.SelectMany(line => line.Shares)
                .Select(share => share.SiteOption)
                .Where(site => !categories.SiteOptions.Contains(site))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (missingSites.Count > 0)
                return XeroApprovalResult.Failed(
                    $"Xero's \"{_options.SiteTrackingCategory}\" tracking category has no option named "
                    + string.Join(", ", missingSites.Select(site => $"\"{site}\""))
                    + " — check the project's Xero site mapping against Xero's tracking options.");

            // Build (and thereby validate against drift) BEFORE touching Xero — creating
            // tracking options for an approval that then fails would mutate Xero for nothing.
            var lineItems = BuildLineItems(invoice, request, categories, out var buildError);
            if (lineItems is null)
                return XeroApprovalResult.Failed(buildError!);

            // Master cost codes are JPMS-owned; create any that Xero doesn't hold yet so
            // the confirmation can be recorded. (Xero caps a category at 100 options — a
            // rejection here surfaces verbatim for the finance team to resolve.)
            var missingCodes = request.Lines.SelectMany(line => line.Shares)
                .Select(share => share.CostCenterCode)
                .Where(code => !categories.CostCodeOptions.Contains(code))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            foreach (var code in missingCodes)
            {
                var optionBody = new JsonObject { ["Name"] = code };
                using var _ = await SendJsonAsync(HttpMethod.Put, token,
                    $"{TrackingCategoriesUrl}/{categories.CostCodeCategoryId}/Options",
                    optionBody, $"create Cost Code option {code}", ct);
                // The lookup is cached (see GetTrackingCategoriesAsync); record the option we
                // just created so an approval moments later doesn't try to create it again.
                categories.CostCodeOptions.Add(code);
            }

            var payload = new JsonObject
            {
                [idProperty] = request.InvoiceId,
                ["Status"] = "AUTHORISED",
                ["LineItems"] = lineItems
            };
            using var response = await SendJsonAsync(HttpMethod.Post, token,
                $"{baseUrl}/{request.InvoiceId}", payload, "approve invoice", ct);

            // The cached snapshot now lies about this invoice's status; drop it so the
            // next sync re-reads rather than resurrecting DRAFT for up to CacheMinutes.
            _cachedSnapshot = null;
            _cachedSnapshotAt = DateTimeOffset.MinValue;

            return XeroApprovalResult.Ok("AUTHORISED");
        }
        catch (XeroCallFailedException failure)
        {
            return XeroApprovalResult.Failed(failure.Message);
        }
    }

    // -- site-only tracking update (SetProject half-step, no approval) -----------------

    public async Task<XeroApprovalResult> SetSiteTrackingAsync(XeroSiteTrackingRequest request, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return XeroApprovalResult.Failed(
                "Xero isn't connected — add the Xero__ClientId / Xero__ClientSecret app settings.");

        try
        {
            var token = await GetAccessTokenAsync(ct);

            var baseUrl = request.IsCreditNote ? CreditNotesUrl : InvoicesUrl;
            var collection = request.IsCreditNote ? "CreditNotes" : "Invoices";
            var idProperty = request.IsCreditNote ? "CreditNoteID" : "InvoiceID";

            // Fresh read, same as approval: the update below replaces the whole line list.
            using var doc = await GetJsonAsync(token, $"{baseUrl}/{request.InvoiceId}", collection.ToLowerInvariant(), ct);
            if (!doc.RootElement.TryGetProperty(collection, out var items)
                || items.ValueKind != JsonValueKind.Array || items.GetArrayLength() == 0)
                return XeroApprovalResult.Failed("Xero returned no invoice for this id — it may have been deleted.");

            var invoice = items[0];
            var status = StringOf(invoice, "Status") ?? "UNKNOWN";
            if (status.Equals("AUTHORISED", StringComparison.OrdinalIgnoreCase)
                || status.Equals("PAID", StringComparison.OrdinalIgnoreCase))
                return XeroApprovalResult.SkippedAlreadyApproved(status);
            if (!status.Equals("DRAFT", StringComparison.OrdinalIgnoreCase)
                && !status.Equals("SUBMITTED", StringComparison.OrdinalIgnoreCase))
                return XeroApprovalResult.Failed(
                    $"The invoice is {status} in Xero — tracking can only be updated on draft or submitted bills.");

            var categories = await GetTrackingCategoriesAsync(token, ct);

            var missingSites = request.Lines
                .Select(line => line.SiteOption)
                .Where(site => site is not null && !categories.SiteOptions.Contains(site))
                .Select(site => site!)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            if (missingSites.Count > 0)
                return XeroApprovalResult.Failed(
                    $"Xero's \"{_options.SiteTrackingCategory}\" tracking category has no option named "
                    + string.Join(", ", missingSites.Select(site => $"\"{site}\""))
                    + " — check the project's Xero site mapping against Xero's tracking options.");

            // Rebuild the full line list: every line passes through as-is except the
            // targets, whose Sites entry is replaced. No amount checks needed — nothing
            // about the money changes, and no lines are split.
            var sitesByLineId = request.Lines.ToDictionary(
                line => line.LineItemId, line => line.SiteOption, StringComparer.OrdinalIgnoreCase);
            var seenLineIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var lineItems = new JsonArray();
            if (invoice.TryGetProperty("LineItems", out var originals) && originals.ValueKind == JsonValueKind.Array)
            {
                foreach (var line in originals.EnumerateArray())
                {
                    var lineItemId = StringOf(line, "LineItemID");
                    if (lineItemId is not null && sitesByLineId.TryGetValue(lineItemId, out var siteOption))
                    {
                        seenLineIds.Add(lineItemId);
                        var copy = CopyLine(line, keepLineItemId: true, keepTracking: false, includeTaxAmount: true);
                        copy["Tracking"] = ReplaceSiteTracking(line, categories, siteOption);
                        lineItems.Add(copy);
                    }
                    else
                    {
                        lineItems.Add(CopyLine(line, keepLineItemId: true, keepTracking: true, includeTaxAmount: true));
                    }
                }
            }

            var unmatched = sitesByLineId.Keys.Where(id => !seenLineIds.Contains(id)).ToList();
            if (unmatched.Count > 0)
                return XeroApprovalResult.Failed(
                    "The bill's lines have changed in Xero since they were synced "
                    + $"({unmatched.Count} line(s) no longer exist). Sync from Xero and try again.");

            // No Status in the payload: the bill stays DRAFT/SUBMITTED — approval only
            // ever happens through the full write-back once every line is allocated.
            var payload = new JsonObject
            {
                [idProperty] = request.InvoiceId,
                ["LineItems"] = lineItems
            };
            using var response = await SendJsonAsync(HttpMethod.Post, token,
                $"{baseUrl}/{request.InvoiceId}", payload, "set site tracking", ct);

            // The cached snapshot now holds stale tracking for this invoice.
            _cachedSnapshot = null;
            _cachedSnapshotAt = DateTimeOffset.MinValue;

            return XeroApprovalResult.Ok(status);
        }
        catch (XeroCallFailedException failure)
        {
            return XeroApprovalResult.Failed(failure.Message);
        }
    }

    /// <summary>
    /// The target line's new tracking: the Sites entry replaced with <paramref name="siteOption"/>
    /// — or removed outright when it is null (unset) — with every other category
    /// (Xero's own Cost Code, anything else) carried over untouched.
    /// </summary>
    private static JsonArray ReplaceSiteTracking(JsonElement line, TrackingCategoryLookup categories, string? siteOption)
    {
        var tracking = new JsonArray();
        if (siteOption is not null)
            tracking.Add(new JsonObject { ["TrackingCategoryID"] = categories.SiteCategoryId, ["Option"] = siteOption });
        if (line.TryGetProperty("Tracking", out var existing) && existing.ValueKind == JsonValueKind.Array)
            foreach (var entry in existing.EnumerateArray())
            {
                var categoryId = StringOf(entry, "TrackingCategoryID");
                if (categoryId is not null
                    && !categoryId.Equals(categories.SiteCategoryId, StringComparison.OrdinalIgnoreCase))
                    tracking.Add(JsonNode.Parse(entry.GetRawText()));
            }
        return tracking;
    }

    // -- site P&L: the job's own monthly income and cost, as the accounts hold it ------

    public async Task<IReadOnlyList<XeroSitePnlMonthFigures>> GetSiteMonthlyPnlAsync(
        string siteOption, DateTime fromMonth, DateTime toMonth, CancellationToken ct)
    {
        if (!_options.IsConfigured)
            return Array.Empty<XeroSitePnlMonthFigures>();

        var token = await GetAccessTokenAsync(ct);
        var categories = await GetTrackingCategoriesAsync(token, ct);
        if (!categories.SiteOptionIdsByName.TryGetValue(siteOption, out var optionId))
            throw new XeroCallFailedException(
                $"Xero's \"{_options.SiteTrackingCategory}\" tracking category has no option named "
                + $"\"{siteOption}\" — check the project's Xero site mapping against Xero's tracking options.");

        var first = new DateTime(fromMonth.Year, fromMonth.Month, 1);
        var last = new DateTime(toMonth.Year, toMonth.Month, 1);
        if (last < first) return Array.Empty<XeroSitePnlMonthFigures>();

        // Newest window first, stepping back twelve months per call: each call covers the
        // window-end month plus up to eleven earlier monthly columns (Xero's periods cap).
        var byMonth = new SortedDictionary<DateTime, PnlTotals>();
        for (var windowEnd = last; windowEnd >= first; windowEnd = windowEnd.AddMonths(-12))
        {
            var windowStart = windowEnd.AddMonths(-11) < first ? first : windowEnd.AddMonths(-11);
            var periods = ((windowEnd.Year - windowStart.Year) * 12) + windowEnd.Month - windowStart.Month;
            var url = $"{ProfitAndLossReportUrl}?fromDate={windowEnd:yyyy-MM-dd}"
                      + $"&toDate={windowEnd.AddMonths(1).AddDays(-1):yyyy-MM-dd}"
                      + $"&trackingCategoryID={categories.SiteCategoryId}&trackingOptionID={optionId}"
                      + (periods > 0 ? $"&timeframe=MONTH&periods={periods}" : "");

            JsonDocument doc;
            try
            {
                doc = await GetJsonAsync(token, url, "site profit and loss report", ct);
            }
            catch (XeroCallFailedException failure) when (failure.Message.Contains("HTTP 403"))
            {
                throw new XeroCallFailedException(
                    "Couldn't read Xero's profit and loss report — the Xero custom connection needs the "
                    + "accounting.reports.read scope ticked in the Xero developer portal. " + failure.Message);
            }

            using (doc)
            {
                ReadPnlColumns(doc, windowEnd, periods, byMonth);
            }
        }

        return byMonth
            .Where(entry => entry.Value.Income != 0m
                            || entry.Value.CostOfSales != 0m
                            || entry.Value.OperatingExpenses != 0m)
            .Select(entry => new XeroSitePnlMonthFigures(
                entry.Key, entry.Value.Income, entry.Value.CostOfSales, entry.Value.OperatingExpenses))
            .ToList();
    }

    private readonly record struct PnlTotals(decimal Income, decimal CostOfSales, decimal OperatingExpenses);

    private enum PnlBucket { Income, CostOfSales, OperatingExpenses }

    /// <summary>
    /// Reads one report's monthly columns into <paramref name="into"/>. With comparison
    /// periods the amount columns run newest → oldest, base period first — months are derived
    /// from that documented order rather than parsed out of the header labels, whose date
    /// format has varied. A column that doesn't align with a requested month is ignored.
    /// Section totals are classified by title or summary label ("Total Income", "Total Cost
    /// of Sales", "Total Operating Expenses" — tolerant of Xero's wording variants); the
    /// Gross/Net Profit sections are derived figures and deliberately skipped. Sections
    /// without a summary row fall back to summing their detail rows.
    /// </summary>
    private static void ReadPnlColumns(
        JsonDocument doc, DateTime windowEnd, int periods, SortedDictionary<DateTime, PnlTotals> into)
    {
        if (!doc.RootElement.TryGetProperty("Reports", out var reports)
            || reports.ValueKind != JsonValueKind.Array || reports.GetArrayLength() == 0)
            return;

        foreach (var section in RowsOf(reports[0]))
        {
            if (StringOf(section, "RowType") != "Section") continue;

            // The section's own title decides the bucket; failing that, the summary row's
            // label ("Total Income") — Xero has shipped both shapes.
            var bucket = PnlBucketOf(StringOf(section, "Title"));

            JsonElement? summaryCells = null;
            var detailTotals = new Dictionary<int, decimal>();
            foreach (var row in RowsOf(section))
            {
                var rowType = StringOf(row, "RowType");
                if (!row.TryGetProperty("Cells", out var cells)
                    || cells.ValueKind != JsonValueKind.Array || cells.GetArrayLength() < 2)
                    continue;

                if (rowType == "SummaryRow")
                {
                    summaryCells = cells;
                    bucket ??= PnlBucketOf(StringOf(cells[0], "Value"));
                }
                else if (rowType == "Row")
                {
                    for (var index = 1; index < cells.GetArrayLength(); index++)
                        detailTotals[index] = (detailTotals.TryGetValue(index, out var sum) ? sum : 0m)
                                              + CellDecimal(cells[index]);
                }
            }
            if (bucket is null) continue;

            decimal ValueAt(int cellIndex) => summaryCells is { } summary
                ? cellIndex < summary.GetArrayLength() ? CellDecimal(summary[cellIndex]) : 0m
                : detailTotals.TryGetValue(cellIndex, out var sum) ? sum : 0m;

            var columns = summaryCells is { } summaryRow
                ? summaryRow.GetArrayLength() - 1
                : detailTotals.Count == 0 ? 0 : detailTotals.Keys.Max();
            for (var column = 0; column < columns && column <= periods; column++)
            {
                var month = windowEnd.AddMonths(-column);
                var value = ValueAt(column + 1); // first cell is the label
                var current = into.TryGetValue(month, out var existing) ? existing : default;
                into[month] = bucket switch
                {
                    PnlBucket.Income => current with { Income = current.Income + value },
                    PnlBucket.CostOfSales => current with { CostOfSales = current.CostOfSales + value },
                    _ => current with { OperatingExpenses = current.OperatingExpenses + value },
                };
            }
        }
    }

    /// <summary>
    /// Which P&L bucket a section belongs to, from its title or summary label. Cost of sales
    /// is tested before income because "Total Cost of Sales" contains "sales"; the derived
    /// profit sections return null so they are never double-counted.
    /// </summary>
    private static PnlBucket? PnlBucketOf(string? label)
    {
        if (string.IsNullOrWhiteSpace(label)) return null;
        var normalised = Normalise(label);
        if (normalised.Contains("grossprofit") || normalised.Contains("netprofit")
            || normalised.Contains("grossloss") || normalised.Contains("netloss"))
            return null;
        if (normalised.Contains("costofsales") || normalised.Contains("directcost"))
            return PnlBucket.CostOfSales;
        if (normalised.Contains("operatingexpense") || normalised.Contains("overhead")
            || normalised is "expenses" or "totalexpenses" or "lessexpenses")
            return PnlBucket.OperatingExpenses;
        if (normalised.Contains("income") || normalised.Contains("turnover")
            || normalised.Contains("revenue") || normalised.Contains("sales"))
            return PnlBucket.Income;
        return null;
    }

    // -- attachments: the supplier's document, viewed from the allocation page ---------

    public async Task<IReadOnlyList<XeroInvoiceAttachment>> ListAttachmentsAsync(
        string invoiceId, bool isCreditNote, CancellationToken ct)
    {
        var token = await GetAccessTokenAsync(ct);
        var baseUrl = isCreditNote ? CreditNotesUrl : InvoicesUrl;

        JsonDocument doc;
        try
        {
            doc = await GetJsonAsync(token, $"{baseUrl}/{invoiceId}/Attachments", "attachments", ct);
        }
        catch (XeroCallFailedException failure) when (failure.Message.Contains("HTTP 403"))
        {
            throw new XeroCallFailedException(
                "Couldn't read the invoice's attachments — the Xero custom connection needs the "
                + "accounting.attachments scope ticked in the Xero developer portal. " + failure.Message);
        }

        using (doc)
        {
            if (!doc.RootElement.TryGetProperty("Attachments", out var items)
                || items.ValueKind != JsonValueKind.Array)
                return Array.Empty<XeroInvoiceAttachment>();

            return items.EnumerateArray()
                .Select(item => new XeroInvoiceAttachment(
                    AttachmentId: StringOf(item, "AttachmentID") ?? "",
                    FileName: StringOf(item, "FileName") ?? "attachment",
                    MimeType: StringOf(item, "MimeType") ?? "application/octet-stream",
                    ContentLength: item.TryGetProperty("ContentLength", out var length)
                        && length.ValueKind == JsonValueKind.Number ? length.GetInt64() : 0))
                .Where(attachment => attachment.AttachmentId.Length > 0)
                .ToList();
        }
    }

    public async Task<XeroAttachmentContent?> GetAttachmentAsync(
        string invoiceId, bool isCreditNote, string fileName, CancellationToken ct)
    {
        // The list gives the attachment's real MimeType — Xero's content endpoint wants it
        // in the Accept header — and confirms the file actually belongs to this invoice.
        var attachments = await ListAttachmentsAsync(invoiceId, isCreditNote, ct);
        var attachment = attachments.FirstOrDefault(candidate =>
            candidate.FileName.Equals(fileName, StringComparison.OrdinalIgnoreCase));
        if (attachment is null) return null;

        var token = await GetAccessTokenAsync(ct);
        var baseUrl = isCreditNote ? CreditNotesUrl : InvoicesUrl;
        var url = $"{baseUrl}/{invoiceId}/Attachments/{Uri.EscapeDataString(attachment.FileName)}";

        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(attachment.MimeType));
        if (!string.IsNullOrWhiteSpace(_options.TenantId))
            request.Headers.Add("xero-tenant-id", _options.TenantId);

        using var response = await _http.SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            _logger.LogWarning("Xero attachment call failed: {Status} {Body}.", (int)response.StatusCode, Truncate(body));
            throw new XeroCallFailedException(
                $"Xero rejected the attachment request with HTTP {(int)response.StatusCode}. {Truncate(body)}");
        }

        var content = await response.Content.ReadAsByteArrayAsync(ct);
        var contentType = response.Content.Headers.ContentType?.MediaType ?? attachment.MimeType;
        return new XeroAttachmentContent(content, contentType, attachment.FileName);
    }

    /// <summary>
    /// Rebuilds the invoice's full line list for the update: untouched lines pass through
    /// as-is (keyed by LineItemID so Xero updates in place), single-centre lines get their
    /// tracking replaced, and split lines are replaced by one new line per cost centre with
    /// pro-rated amounts. Returns null (with an error) when the invoice no longer matches
    /// the stored allocation — edited amounts or removed lines — because silently approving
    /// figures nobody allocated would corrupt the accounts.
    /// </summary>
    private JsonArray? BuildLineItems(
        JsonElement invoice, XeroApprovalRequest request, TrackingCategoryLookup categories, out string? error)
    {
        error = null;
        var instructionsByLineId = request.Lines.ToDictionary(
            line => line.LineItemId, StringComparer.OrdinalIgnoreCase);
        var seenLineIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        var vatInclusive = string.Equals(StringOf(invoice, "LineAmountTypes"), "Inclusive", StringComparison.OrdinalIgnoreCase);
        var result = new JsonArray();

        if (invoice.TryGetProperty("LineItems", out var lineItems) && lineItems.ValueKind == JsonValueKind.Array)
        {
            foreach (var line in lineItems.EnumerateArray())
            {
                var lineItemId = StringOf(line, "LineItemID");
                if (lineItemId is null || !instructionsByLineId.TryGetValue(lineItemId, out var instruction))
                {
                    // Not a queued cost-of-sales line — pass through untouched.
                    result.Add(CopyLine(line, keepLineItemId: true, keepTracking: true, includeTaxAmount: true));
                    continue;
                }
                seenLineIds.Add(lineItemId);

                // Guard against drift: the allocation was made against the stored net;
                // if the bill was edited in Xero since the last sync, stop and ask for
                // a re-sync + re-allocation instead of approving changed figures.
                var lineAmount = DecimalOf(line, "LineAmount");
                var taxAmount = DecimalOf(line, "TaxAmount");
                var freshNet = vatInclusive ? lineAmount - taxAmount : lineAmount;
                var allocatedNet = instruction.Shares.Sum(share => share.Net);
                if (Math.Abs(freshNet - allocatedNet) > 0.01m)
                {
                    error = $"Line \"{StringOf(line, "Description")}\" is {freshNet:0.00} net in Xero but was allocated as "
                            + $"{allocatedNet:0.00} — the bill has changed since it was synced. Sync from Xero and re-allocate.";
                    return null;
                }

                if (instruction.Shares.Count == 1)
                {
                    var share = instruction.Shares[0];
                    var copy = CopyLine(line, keepLineItemId: true, keepTracking: false, includeTaxAmount: true);
                    copy["Tracking"] = TrackingFor(categories, share.SiteOption, share.CostCenterCode);
                    result.Add(copy);
                }
                else
                {
                    // One Xero line per share (its own site + cost code — shares can point
                    // at different projects). Both the raw LineAmount (VAT-inclusive or not
                    // — proportions are identical) and the original TaxAmount are pro-rated
                    // with the same penny-safe maths, so the bill's net, tax and gross
                    // totals are all unchanged to the penny by the split — per-line tax
                    // recalculation by Xero could otherwise drift by a penny per piece.
                    var weights = instruction.Shares.Select(share => share.Net).ToList();
                    var amounts = XeroSplitMaths.ProportionalShares(lineAmount, weights);
                    var taxes = XeroSplitMaths.ProportionalShares(taxAmount, weights);
                    var description = StringOf(line, "Description");
                    for (var i = 0; i < instruction.Shares.Count; i++)
                    {
                        var share = instruction.Shares[i];
                        var piece = CopyLine(line, keepLineItemId: false, keepTracking: false, includeTaxAmount: false);
                        piece["Description"] = $"{description} [{share.CostCenterCode}]";
                        piece["Quantity"] = 1m;
                        piece["UnitAmount"] = amounts[i];
                        piece["LineAmount"] = amounts[i];
                        piece["TaxAmount"] = taxes[i];
                        piece["Tracking"] = TrackingFor(categories, share.SiteOption, share.CostCenterCode);
                        result.Add(piece);
                    }
                }
            }
        }

        var unmatched = instructionsByLineId.Keys.Where(id => !seenLineIds.Contains(id)).ToList();
        if (unmatched.Count > 0)
        {
            error = "The bill's lines have changed in Xero since they were synced "
                    + $"({unmatched.Count} allocated line(s) no longer exist). Sync from Xero and re-allocate.";
            return null;
        }

        return result;
    }

    /// <summary>Copies the fields the update needs off one original line item.</summary>
    private static JsonObject CopyLine(JsonElement line, bool keepLineItemId, bool keepTracking, bool includeTaxAmount)
    {
        var copy = new JsonObject();
        if (keepLineItemId && StringOf(line, "LineItemID") is { } id) copy["LineItemID"] = id;
        if (StringOf(line, "Description") is { } description) copy["Description"] = description;
        if (line.TryGetProperty("Quantity", out var quantity) && quantity.ValueKind == JsonValueKind.Number)
            copy["Quantity"] = quantity.GetDecimal();
        if (line.TryGetProperty("UnitAmount", out var unitAmount) && unitAmount.ValueKind == JsonValueKind.Number)
            copy["UnitAmount"] = unitAmount.GetDecimal();
        if (line.TryGetProperty("LineAmount", out var lineAmount) && lineAmount.ValueKind == JsonValueKind.Number)
            copy["LineAmount"] = lineAmount.GetDecimal();
        if (includeTaxAmount && line.TryGetProperty("TaxAmount", out var taxAmount) && taxAmount.ValueKind == JsonValueKind.Number)
            copy["TaxAmount"] = taxAmount.GetDecimal();
        if (StringOf(line, "AccountCode") is { } accountCode) copy["AccountCode"] = accountCode;
        if (StringOf(line, "TaxType") is { } taxType) copy["TaxType"] = taxType;
        if (StringOf(line, "ItemCode") is { } itemCode) copy["ItemCode"] = itemCode;
        if (keepTracking && line.TryGetProperty("Tracking", out var tracking) && tracking.ValueKind == JsonValueKind.Array)
            copy["Tracking"] = JsonNode.Parse(tracking.GetRawText());
        return copy;
    }

    private static JsonArray TrackingFor(TrackingCategoryLookup categories, string siteOption, string costCode) => new(
        new JsonObject { ["TrackingCategoryID"] = categories.SiteCategoryId, ["Option"] = siteOption },
        new JsonObject { ["TrackingCategoryID"] = categories.CostCodeCategoryId, ["Option"] = costCode });

    private sealed record TrackingCategoryLookup(
        string SiteCategoryId,
        HashSet<string> SiteOptions,
        string CostCodeCategoryId,
        HashSet<string> CostCodeOptions,
        // Option name → TrackingOptionID for the Sites category — the P&L report is filtered
        // by option ID, not name. Same case-insensitive matching as SiteOptions.
        IReadOnlyDictionary<string, string> SiteOptionIdsByName);

    /// <summary>
    /// Reads the organisation's tracking categories and finds the Sites and Cost Code ones
    /// by their configured names (spacing/case tolerant). Requires the custom connection's
    /// accounting.settings scope — the failure message says so when Xero refuses.
    /// </summary>
    private async Task<TrackingCategoryLookup> GetTrackingCategoriesAsync(string token, CancellationToken ct)
    {
        if (_trackingLookup is not null
            && DateTimeOffset.UtcNow < _trackingLookupAt.AddMinutes(_options.CacheMinutes))
            return _trackingLookup;

        JsonDocument doc;
        try
        {
            doc = await GetJsonAsync(token, TrackingCategoriesUrl, "tracking categories", ct);
        }
        catch (XeroCallFailedException failure) when (failure.Message.Contains("HTTP 403"))
        {
            // Only a 403 is a scope problem. Anything else (rate limit, outage) keeps its own
            // story — a 429 dressed up as "missing scope" sends whoever reads it hunting the
            // Xero portal for a setting that is already ticked.
            throw new XeroCallFailedException(
                "Couldn't read Xero's tracking categories — the custom connection needs the "
                + "accounting.settings scope to confirm cost codes. " + failure.Message);
        }

        using (doc)
        {
            (string Id, HashSet<string> Options, Dictionary<string, string> OptionIds)? sites = null, costCodes = null;
            if (doc.RootElement.TryGetProperty("TrackingCategories", out var trackingCategories)
                && trackingCategories.ValueKind == JsonValueKind.Array)
            {
                foreach (var category in trackingCategories.EnumerateArray())
                {
                    var name = StringOf(category, "Name");
                    var id = StringOf(category, "TrackingCategoryID");
                    if (name is null || id is null) continue;

                    var options = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    var optionIds = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    if (category.TryGetProperty("Options", out var optionElements) && optionElements.ValueKind == JsonValueKind.Array)
                        foreach (var option in optionElements.EnumerateArray())
                            if (StringOf(option, "Name") is { } optionName)
                            {
                                options.Add(optionName);
                                if (StringOf(option, "TrackingOptionID") is { } optionId)
                                    optionIds[optionName] = optionId;
                            }

                    if (Normalise(name) == Normalise(_options.SiteTrackingCategory)) sites = (id, options, optionIds);
                    else if (Normalise(name) == Normalise(_options.CostCodeTrackingCategory)) costCodes = (id, options, optionIds);
                }
            }

            if (sites is null)
                throw new XeroCallFailedException(
                    $"Xero has no tracking category named \"{_options.SiteTrackingCategory}\".");
            if (costCodes is null)
                throw new XeroCallFailedException(
                    $"Xero has no tracking category named \"{_options.CostCodeTrackingCategory}\".");

            var lookup = new TrackingCategoryLookup(
                sites.Value.Id, sites.Value.Options, costCodes.Value.Id, costCodes.Value.Options,
                sites.Value.OptionIds);
            _trackingLookup = lookup;
            _trackingLookupAt = DateTimeOffset.UtcNow;
            return lookup;
        }
    }

    /// <summary>POST/PUT with a JSON body; failures throw with Xero's validation messages extracted.</summary>
    private async Task<JsonDocument> SendJsonAsync(
        HttpMethod method, string token, string url, JsonObject body, string what, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(method, url)
        {
            Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json")
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if (!string.IsNullOrWhiteSpace(_options.TenantId))
            request.Headers.Add("xero-tenant-id", _options.TenantId);

        using var response = await _http.SendAsync(request, ct);
        var responseBody = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("Xero {What} call failed: {Status} {Body}.", what, (int)response.StatusCode, Truncate(responseBody));
            throw new XeroCallFailedException(
                $"Xero rejected the {what} request with HTTP {(int)response.StatusCode}. {ExtractXeroErrors(responseBody)}");
        }

        return JsonDocument.Parse(responseBody);
    }

    /// <summary>
    /// Xero's 400s bury the useful text in ValidationErrors[].Message several levels deep;
    /// pull every Message out so "Account code X is not valid" reaches the allocation page
    /// instead of a truncated JSON blob.
    /// </summary>
    private static string ExtractXeroErrors(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            var messages = new List<string>();
            CollectMessages(doc.RootElement, messages);
            if (messages.Count > 0) return string.Join(" ", messages.Distinct().Take(5));
        }
        catch (JsonException) { }
        return LooksBinary(body)
            ? "(Xero's response body wasn't readable text — likely compressed content the client couldn't decode.)"
            : Truncate(body);

        static void CollectMessages(JsonElement element, List<string> messages)
        {
            switch (element.ValueKind)
            {
                case JsonValueKind.Object:
                    foreach (var property in element.EnumerateObject())
                    {
                        if (property.Name is "Message" && property.Value.ValueKind == JsonValueKind.String)
                            messages.Add(property.Value.GetString()!);
                        else
                            CollectMessages(property.Value, messages);
                    }
                    break;
                case JsonValueKind.Array:
                    foreach (var item in element.EnumerateArray()) CollectMessages(item, messages);
                    break;
            }
        }
    }

    private async Task<XeroTransactionsSnapshot> FetchSnapshotAsync(CancellationToken ct)
    {
        string token;
        try
        {
            token = await GetAccessTokenAsync(ct);
        }
        catch (XeroCallFailedException tokenFailure)
        {
            return XeroTransactionsSnapshot.Failed(tokenFailure.Message);
        }

        var accountNames = await GetAccountNamesAsync(token, ct);

        var transactions = new List<XeroTransaction>();
        var truncated = false;
        try
        {
            // Bills first, then supplier credit notes so spend can be netted off downstream.
            truncated |= await FetchAllPagesAsync(token, InvoicesUrl, "Invoices", "ACCPAY", accountNames, transactions, ct);
            truncated |= await FetchAllPagesAsync(token, CreditNotesUrl, "CreditNotes", "ACCPAYCREDIT", accountNames, transactions, ct);
        }
        catch (XeroCallFailedException callFailure)
        {
            return XeroTransactionsSnapshot.Failed(callFailure.Message);
        }

        return new XeroTransactionsSnapshot(true, null, _options.FromDate, DateTimeOffset.UtcNow, truncated, transactions);
    }

    /// <summary>Pages through one Xero collection into <paramref name="into"/>; true = page cap hit with data left.</summary>
    private async Task<bool> FetchAllPagesAsync(
        string token, string baseUrl, string collectionProperty, string xeroType,
        IReadOnlyDictionary<string, string> accountNames, List<XeroTransaction> into, CancellationToken ct)
    {
        for (var page = 1; page <= _options.MaxPages; page++)
        {
            var pageOfTransactions = await FetchPageAsync(token, baseUrl, collectionProperty, xeroType, page, accountNames, ct);
            into.AddRange(pageOfTransactions);
            if (pageOfTransactions.Count < PageSize) return false; // Short page — no more to fetch.
        }
        return true;
    }

    private async Task<IReadOnlyList<XeroTransaction>> FetchPageAsync(
        string token, string baseUrl, string collectionProperty, string xeroType, int page,
        IReadOnlyDictionary<string, string> accountNames, CancellationToken ct)
    {
        // Purchase side only, inside the reporting window. Paged responses include line items,
        // which carry the site / cost-code tracking.
        var from = _options.FromDate;
        var where = $"Type==\"{xeroType}\" AND Date >= DateTime({from.Year},{from.Month:D2},{from.Day:D2})";
        var url = $"{baseUrl}?page={page}&where={Uri.EscapeDataString(where)}&order={Uri.EscapeDataString("Date DESC")}";

        using var doc = await GetJsonAsync(token, url, collectionProperty.ToLowerInvariant(), ct);

        if (!doc.RootElement.TryGetProperty(collectionProperty, out var items) || items.ValueKind != JsonValueKind.Array)
            return Array.Empty<XeroTransaction>();

        return items.EnumerateArray().Select(item => ReadTransaction(item, xeroType, accountNames)).ToList();
    }

    /// <summary>
    /// Account code → account name from the chart of accounts. Best effort: if the custom connection
    /// lacks the accounting.settings scope (or the call fails) lines simply show the bare code.
    /// </summary>
    private async Task<IReadOnlyDictionary<string, string>> GetAccountNamesAsync(string token, CancellationToken ct)
    {
        if (_accountNamesByCode is not null && DateTimeOffset.UtcNow < _accountNamesFetchedAt.AddHours(1))
            return _accountNamesByCode;

        try
        {
            using var doc = await GetJsonAsync(token, AccountsUrl, "accounts", ct);
            var names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (doc.RootElement.TryGetProperty("Accounts", out var accounts) && accounts.ValueKind == JsonValueKind.Array)
            {
                foreach (var account in accounts.EnumerateArray())
                {
                    var code = StringOf(account, "Code");
                    var name = StringOf(account, "Name");
                    if (code is not null && name is not null) names[code] = name;
                }
            }
            _accountNamesByCode = names;
            _accountNamesFetchedAt = DateTimeOffset.UtcNow;
            return names;
        }
        catch (XeroCallFailedException accountsFailure)
        {
            _logger.LogInformation("Chart of accounts unavailable ({Message}); showing account codes only.", accountsFailure.Message);
            return _accountNamesByCode ?? new Dictionary<string, string>();
        }
    }

    private async Task<JsonDocument> GetJsonAsync(string token, string url, string what, CancellationToken ct)
    {
        // Xero's rate limit is 60 calls/min, and the multi-call reads (site P&L windows,
        // paged invoices) can brush it. A 429 is a pause, not a refusal: honour Retry-After
        // (capped at 30s) a few times before treating it as a failure.
        const int maxRateLimitRetries = 3;
        for (var attempt = 0; ; attempt++)
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            if (!string.IsNullOrWhiteSpace(_options.TenantId))
                request.Headers.Add("xero-tenant-id", _options.TenantId);

            using var response = await _http.SendAsync(request, ct);

            if ((int)response.StatusCode == 429 && attempt < maxRateLimitRetries)
            {
                var waitSeconds = Math.Clamp(
                    (int)(response.Headers.RetryAfter?.Delta?.TotalSeconds ?? 15d), 1, 30);
                _logger.LogInformation(
                    "Xero rate limit hit on {What}; waiting {Wait}s before retry {Attempt}/{Max}.",
                    what, waitSeconds, attempt + 1, maxRateLimitRetries);
                await Task.Delay(TimeSpan.FromSeconds(waitSeconds), ct);
                continue;
            }

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                _logger.LogWarning("Xero {What} call failed: {Status} {Body}.", what, (int)response.StatusCode, Truncate(body));
                throw new XeroCallFailedException($"Xero rejected the {what} request with HTTP {(int)response.StatusCode}. {ExtractXeroErrors(body)}");
            }

            await using var stream = await response.Content.ReadAsStreamAsync(ct);
            return await JsonDocument.ParseAsync(stream, cancellationToken: ct);
        }
    }

    /// <summary>
    /// Maps one invoice or credit note. The two shapes differ only in id/number field names
    /// (InvoiceID/InvoiceNumber vs CreditNoteID/CreditNoteNumber) and credit notes carry
    /// RemainingCredit instead of AmountDue.
    /// </summary>
    private XeroTransaction ReadTransaction(JsonElement item, string xeroType, IReadOnlyDictionary<string, string> accountNames) => new(
        TransactionId: StringOf(item, "InvoiceID") ?? StringOf(item, "CreditNoteID") ?? Guid.NewGuid().ToString(),
        Type: StringOf(item, "Type") ?? xeroType,
        Number: StringOf(item, "InvoiceNumber") ?? StringOf(item, "CreditNoteNumber"),
        Reference: StringOf(item, "Reference"),
        ContactName: item.TryGetProperty("Contact", out var contact) ? StringOf(contact, "Name") : null,
        Date: DateOf(item, "DateString", "Date"),
        DueDate: DateOf(item, "DueDateString", "DueDate"),
        Status: StringOf(item, "Status") ?? "UNKNOWN",
        SubTotal: DecimalOf(item, "SubTotal"),
        TotalTax: DecimalOf(item, "TotalTax"),
        Total: DecimalOf(item, "Total"),
        AmountDue: item.TryGetProperty("AmountDue", out _) ? DecimalOf(item, "AmountDue") : DecimalOf(item, "RemainingCredit"),
        AmountPaid: DecimalOf(item, "AmountPaid"),
        CurrencyCode: StringOf(item, "CurrencyCode"),
        Lines: ReadLines(item, accountNames),
        HasAttachments: BoolOf(item, "HasAttachments"));

    private IReadOnlyList<XeroTransactionLine> ReadLines(JsonElement invoice, IReadOnlyDictionary<string, string> accountNames)
    {
        if (!invoice.TryGetProperty("LineItems", out var lineItems) || lineItems.ValueKind != JsonValueKind.Array)
            return Array.Empty<XeroTransactionLine>();

        // Invoices entered as amounts-inclusive-of-VAT carry VAT inside LineAmount
        // (LineAmountTypes = "Inclusive"); subtract the line's tax so LineAmount is always net.
        // Without this, VAT-inclusive bills overstate the cost-code split by their VAT.
        var vatInclusive = string.Equals(StringOf(invoice, "LineAmountTypes"), "Inclusive", StringComparison.OrdinalIgnoreCase);

        return lineItems.EnumerateArray().Select(line =>
        {
            var accountCode = StringOf(line, "AccountCode");
            var taxAmount = DecimalOf(line, "TaxAmount");
            var lineAmount = DecimalOf(line, "LineAmount");
            return new XeroTransactionLine(
                LineItemId: StringOf(line, "LineItemID"),
                Description: StringOf(line, "Description"),
                Quantity: DecimalOf(line, "Quantity"),
                UnitAmount: DecimalOf(line, "UnitAmount"),
                LineAmount: vatInclusive ? lineAmount - taxAmount : lineAmount,
                TaxAmount: taxAmount,
                AccountCode: accountCode,
                AccountName: accountCode is not null && accountNames.TryGetValue(accountCode, out var name) ? name : null,
                Site: TrackingOptionOf(line, _options.SiteTrackingCategory),
                CostCode: TrackingOptionOf(line, _options.CostCodeTrackingCategory));
        }).ToList();
    }

    /// <summary>
    /// Reads the option of the named tracking category off a line, tolerating spacing/case
    /// differences ("Cost code" vs "CostCode"). Line tracking shape: [{ "Name": …, "Option": … }].
    /// </summary>
    private static string? TrackingOptionOf(JsonElement line, string categoryName)
    {
        if (!line.TryGetProperty("Tracking", out var tracking) || tracking.ValueKind != JsonValueKind.Array)
            return null;

        foreach (var entry in tracking.EnumerateArray())
        {
            var name = StringOf(entry, "Name");
            if (name is not null && Normalise(name) == Normalise(categoryName))
                return StringOf(entry, "Option");
        }
        return null;
    }

    private static string Normalise(string categoryName) =>
        categoryName.Replace(" ", "").ToLowerInvariant();

    private static string? StringOf(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;

    private static decimal DecimalOf(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.Number
            ? value.GetDecimal()
            : 0m;

    private static bool BoolOf(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.True;

    /// <summary>
    /// Xero's JSON carries dates twice: an ISO "…String" field and a legacy "/Date(ms+0000)/" field.
    /// Prefer the ISO one; fall back to parsing the epoch milliseconds out of the legacy form.
    /// </summary>
    private static DateTime? DateOf(JsonElement element, string isoProperty, string legacyProperty)
    {
        var iso = StringOf(element, isoProperty);
        if (iso is not null && DateTime.TryParse(iso, out var parsed)) return parsed;

        var legacy = StringOf(element, legacyProperty);
        if (legacy is null) return null;

        var start = legacy.IndexOf('(');
        var end = legacy.IndexOfAny(new[] { '+', '-', ')' }, start + 1);
        if (start < 0 || end <= start) return null;

        return long.TryParse(legacy[(start + 1)..end], out var epochMs)
            ? DateTimeOffset.FromUnixTimeMilliseconds(epochMs).UtcDateTime
            : null;
    }

    private async Task<string> GetAccessTokenAsync(CancellationToken ct)
    {
        if (_accessToken is not null && DateTimeOffset.UtcNow < _accessTokenExpiresAt)
            return _accessToken;

        await _tokenLock.WaitAsync(ct);
        try
        {
            if (_accessToken is not null && DateTimeOffset.UtcNow < _accessTokenExpiresAt)
                return _accessToken;

            // Omit the scope parameter unless explicitly configured — Xero then grants everything
            // the custom connection holds, whereas a mismatch fails with invalid_scope.
            var form = new Dictionary<string, string> { ["grant_type"] = "client_credentials" };
            if (!string.IsNullOrWhiteSpace(_options.Scopes))
                form["scope"] = _options.Scopes;

            using var request = new HttpRequestMessage(HttpMethod.Post, TokenUrl)
            {
                Content = new FormUrlEncodedContent(form)
            };
            var credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_options.ClientId}:{_options.ClientSecret}"));
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", credentials);

            using var response = await _http.SendAsync(request, ct);
            var body = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("Xero token call failed: {Status} {Body}.", (int)response.StatusCode, Truncate(body));
                throw new XeroCallFailedException(
                    $"Xero rejected the credentials with HTTP {(int)response.StatusCode}. Check Xero__ClientId / Xero__ClientSecret and that the custom connection has an accounting scope (e.g. accounting.transactions) ticked in the Xero developer portal. {Truncate(body)}");
            }

            using var doc = JsonDocument.Parse(body);
            var token = doc.RootElement.GetProperty("access_token").GetString()
                ?? throw new XeroCallFailedException("Xero's token response contained no access_token.");
            var expiresInSeconds = doc.RootElement.TryGetProperty("expires_in", out var expiry) && expiry.TryGetInt32(out var seconds)
                ? seconds
                : 1800;

            _accessToken = token;
            _accessTokenExpiresAt = DateTimeOffset.UtcNow.AddSeconds(expiresInSeconds - 60);
            return token;
        }
        finally
        {
            _tokenLock.Release();
        }
    }

    private static string Truncate(string value) =>
        value.Length <= 300 ? value : value[..300] + "…";

    /// <summary>
    /// True when a response body decoded to unprintable garbage (U+FFFD replacement chars or raw
    /// control bytes) — a compressed body read as text, not anything worth showing a user.
    /// </summary>
    private static bool LooksBinary(string value) =>
        value.Any(ch => ch == '�' || (char.IsControl(ch) && ch is not ('\r' or '\n' or '\t')));
}

/// <summary>Internal signal that a Xero call failed with a message safe to show in the snapshot.</summary>
internal sealed class XeroCallFailedException : Exception
{
    public XeroCallFailedException(string message) : base(message) { }
}
