using System.ComponentModel.DataAnnotations;

namespace Jewel.JPMS.Api.Data.Entities;

// One per project: the client-retention terms and the confirmed state of the two release
// milestones. Forecast amounts and due dates are never stored — they're calculated from
// the valuation figures (see RetentionSchedule in contracts).
public sealed class ProjectRetentionEntity
{
    [Key, MaxLength(64)] public string ProjectRetentionId { get; set; } = "";
    [MaxLength(64)]      public string ProjectId { get; set; } = "";
    public decimal RetentionPercent { get; set; }
    public decimal CompletionReleasePercent { get; set; }
    // Cash-up-front deposit % of the contract sum, released back to the client against
    // each valuation's contract-side works. 0 = no deposit on this project.
    public decimal DepositPercent { get; set; }
    // Deposit releases settled before the portal began deducting them from claims —
    // excluded from every future claim's deduction.
    public decimal DepositReleasedOpening { get; set; }
    public int DefectsPeriodMonths { get; set; }
    public DateTimeOffset? PracticalCompletionAt { get; set; }
    public DateTimeOffset? CompletionReleaseConfirmedAt { get; set; }
    public decimal CompletionReleaseAmount { get; set; }
    public DateTimeOffset? FinalReleaseConfirmedAt { get; set; }
    public decimal FinalReleaseAmount { get; set; }
}
