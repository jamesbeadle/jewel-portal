-- ============================================================================
-- NOTE: CostCode values use the JBB Cost Code Master codes (trade-prefixed, per JBB_CostCode_Master v2.1) seeded
-- by seed-cost-centers.sql. Remapped from the original JBB-* buckets on
-- 2026-07-07 -- audit trail: scripts/cost-code-remap-review.csv.
-- Seed: Woodhouse Lane -- contract values (Valuation Report line items)
-- ----------------------------------------------------------------------------
-- Project : Nichols Nymet, Woodhouse Lane, Dorking, RH5 6NN  (JBB-2026-004)
-- ProjectId: c16a737d8e1347f28917183b77360f1d
--
-- Seeds the CONTRACT SCOPE only, taken from the Valuation 7 workbook (May 26).
-- A single Contract Works block makes up the Contract Sum; the workbook's
-- GBP 5,000 "Contingency sum" sits inline under Preliminaries (kept there,
-- costed JBB-RSK) and its one "Provisional sum" line is LineType 1:
--
--     Contract Sum      GBP 536,040.95
--
-- Variations (V01..V18, net GBP 40,006.70) are NOT seeded here -- they belong
-- in a separate variations seed, as per the By France pattern. Per-valuation
-- claim history (Claim 1..10) is claim data (ValuationClaims/ClaimLines), not
-- bill structure.
--
-- The workbook has no NRM2 references; SectionCode is assigned sequentially
-- (01..20) in workbook order. Sub-group headers (Main House, ceilings / roofs,
-- lighting schedule notes) are folded into their parent sections. CostCode
-- maps each section to the Jewel cost-centre master (JBB-*, from
-- seed-cost-centers.sql); the workbook's own numeric codes (0001..0024) are
-- dropped. "Omit item Vnn" comments are informational: those lines are omitted
-- by variations in the register, so they stay Priced here.
--
-- ElementType: 0=ContractWorks 1=PcSum 2=Contingency 3=Variation
-- LineType   : 0=Priced 1=ProvisionalSum 2=Omit 3=Declined 4=Tbc
--
-- Idempotent: keyed on stable ValuationLineItemId values (wh-cw-NNN). A re-run
-- refreshes every field via MERGE. Variation lines for this project are left
-- untouched. Safe to run repeatedly.
-- ============================================================================

MERGE INTO [dbo].[ValuationLineItems] AS target
USING (VALUES
    (N'wh-cw-001', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'SCAFF-STD', N'Scaffolding', N'm2', 120.0000, 48.0000, 5760.0000, N'', 1),
    (N'wh-cw-002', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'PRELIMS-SMG', N'Site manager', N'week', 40.0000, 1500.0000, 60000.0000, N'', 2),
    (N'wh-cw-003', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'ENABLE-SKP', N'Rubbish removal', N'skips', 24.0000, 380.0000, 9120.0000, N'', 3),
    (N'wh-cw-004', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'PRELIMS-WC', N'Temporary toilet', N'week', 40.0000, 90.0000, 3600.0000, N'', 4),
    (N'wh-cw-005', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'PRELIMS-HSC', N'CDM', N'item', 1.0000, 1200.0000, 1200.0000, N'', 5),
    (N'wh-cw-006', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'PRELIMS-WEL', N'Health, safety & welfare', N'item', 40.0000, 125.0000, 5000.0000, N'', 6),
    (N'wh-cw-007', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'HAND-CLI', N'Clean on completion', N'item', 1.0000, 850.0000, 850.0000, N'', 7),
    (N'wh-cw-008', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'PRELIMS-SET', N'Tree protection', N'item', 1.0000, 550.0000, 550.0000, N'', 8),
    (N'wh-cw-009', N'c16a737d8e1347f28917183b77360f1d', 0, N'01', N'Prelimianries & preambles', N'', N'', 0, N'HAND-MSC', N'Contingency sum', N'item', 1.0000, 5000.0000, 5000.0000, N'', 9),
    (N'wh-cw-010', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Isolate electrical installation in connection with demolitions & strip out as required', N'item', 1.0000, 500.0000, 500.0000, N'', 10),
    (N'wh-cw-011', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Ditto plumbing & heating installation', N'item', 1.0000, 650.0000, 650.0000, N'', 11),
    (N'wh-cw-012', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove fireplace, gas fires & false chimneys', N'item', 1.0000, 585.0000, 585.0000, N'', 12),
    (N'wh-cw-013', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove existing built in waredrobes', N'item', 1.0000, 120.0000, 120.0000, N'', 13),
    (N'wh-cw-014', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove flooring, tiles, skirtings, picture rail, cove, fittings etc.', N'item', 1.0000, 550.0000, 550.0000, N'', 14),
    (N'wh-cw-015', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove kitchen units, worktops & appliances', N'item', 1.0000, 195.0000, 195.0000, N'', 15),
    (N'wh-cw-016', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove sanitary from WC & FF bathroom', N'item', 1.0000, 240.0000, 240.0000, N'', 16),
    (N'wh-cw-017', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove internal doors', N'nr', 7.0000, 18.0000, 126.0000, N'', 17),
    (N'wh-cw-018', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Demolish internal walls to form new layout', N'm2', 16.0000, 36.0000, 576.0000, N'', 18),
    (N'wh-cw-019', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove plasterboard ceilings to areas required', N'm2', 80.0000, 10.0000, 800.0000, N'', 19),
    (N'wh-cw-020', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Break up existing floor ready for new insulation & screed', N'm2', 26.0000, 28.0000, 728.0000, N'', 20),
    (N'wh-cw-021', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove existing balustrade & handrail', N'item', 1.0000, 80.0000, 80.0000, N'', 21),
    (N'wh-cw-022', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'CARP-1FX', N'Remove loft access hatch', N'item', 1.0000, 55.0000, 55.0000, N'Omit item V02', 22),
    (N'wh-cw-023', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove windows & external doors', N'item', 1.0000, 550.0000, 550.0000, N'', 23),
    (N'wh-cw-024', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-STS', N'Erect temporary propping to existing construction', N'm', 12.0000, 125.0000, 1500.0000, N'', 24),
    (N'wh-cw-025', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Demolish external walls to form new layout', N'm2', 18.0000, 90.0000, 1620.0000, N'', 25),
    (N'wh-cw-026', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'MEC-DRN', N'Grub out redundant drainage runs', N'item', 1.0000, 425.0000, 425.0000, N'', 26),
    (N'wh-cw-027', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'ENABLE-DEM', N'Remove & relocate existing shed', N'item', 1.0000, 350.0000, 350.0000, N'', 27),
    (N'wh-cw-028', N'c16a737d8e1347f28917183b77360f1d', 0, N'02', N'Demolition', N'', N'', 0, N'SUB-GWK', N'Remove existing paving, retaining walls, etc to new areas', N'm2', 60.0000, 18.0000, 1080.0000, N'', 28),
    (N'wh-cw-029', N'c16a737d8e1347f28917183b77360f1d', 0, N'03', N'Excavation & earthwork', N'', N'', 0, N'SUB-EXC', N'Excavate to reduce levels & remove spoil', N'm3', 8.0000, 110.0000, 880.0000, N'', 29),
    (N'wh-cw-030', N'c16a737d8e1347f28917183b77360f1d', 0, N'03', N'Excavation & earthwork', N'', N'', 0, N'SUB-EXC', N'Excavate foundations 500 x 1000 mm & remove spoil', N'm3', 7.0000, 145.0000, 1015.0000, N'', 30),
    (N'wh-cw-031', N'c16a737d8e1347f28917183b77360f1d', 0, N'03', N'Excavation & earthwork', N'', N'', 0, N'SUB-EXC', N'Excavate for ground beam & remove spoil', N'm3', 4.0000, 145.0000, 580.0000, N'', 31),
    (N'wh-cw-032', N'c16a737d8e1347f28917183b77360f1d', 0, N'03', N'Excavation & earthwork', N'', N'', 0, N'SUB-EXC', N'Excavate pad foundations & remove spoil', N'm3', 4.0000, 198.0000, 792.0000, N'', 32),
    (N'wh-cw-033', N'c16a737d8e1347f28917183b77360f1d', 0, N'04', N'Concrete works', N'', N'', 0, N'SUB-CON', N'Concrete in foundations & ground beam', N'm3', 11.0000, 170.0000, 1870.0000, N'', 33),
    (N'wh-cw-034', N'c16a737d8e1347f28917183b77360f1d', 0, N'04', N'Concrete works', N'', N'', 0, N'SUB-CON', N'150 mm hardcore blinded with sand', N'm2', 22.0000, 38.0000, 836.0000, N'', 34),
    (N'wh-cw-035', N'c16a737d8e1347f28917183b77360f1d', 0, N'04', N'Concrete works', N'', N'', 0, N'SUB-CON', N'150 mm bed of concrete', N'm2', 22.0000, 88.0000, 1936.0000, N'', 35),
    (N'wh-cw-036', N'c16a737d8e1347f28917183b77360f1d', 0, N'04', N'Concrete works', N'', N'', 0, N'SUB-CON', N'A393 mesh to slab', N'm2', 22.0000, 36.0000, 792.0000, N'', 36),
    (N'wh-cw-037', N'c16a737d8e1347f28917183b77360f1d', 0, N'04', N'Concrete works', N'', N'', 0, N'WPF-DMP', N'Damp proof membranes 1200 g', N'm2', 22.0000, 16.0000, 352.0000, N'', 37),
    (N'wh-cw-038', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'SUB-EXC', N'Excavate & lay new underground drainage runs', N'item', 1.0000, 5760.0000, 5760.0000, N'', 38),
    (N'wh-cw-039', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'MEC-DRN', N'Provide drainage from new rainwater pipe, back inlet gulley & connection to existing drainage', N'item', 1.0000, 240.0000, 240.0000, N'', 39),
    (N'wh-cw-040', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'MEC-DRN', N'Make connection of new drainage to existing runs', N'item', 1.0000, 250.0000, 250.0000, N'', 40),
    (N'wh-cw-041', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'MEC-DRN', N'New inspection chambers', N'nr', 2.0000, 645.0000, 1290.0000, N'', 41),
    (N'wh-cw-042', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'SUB-DRN', N'New soakaway', N'nr', 1.0000, 1550.0000, 1550.0000, N'', 42),
    (N'wh-cw-043', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'MEC-DRN', N'Aco slot drains', N'm', 20.0000, 155.0000, 3100.0000, N'', 43),
    (N'wh-cw-044', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'MEC-DRN', N'New covers to existing manholes', N'item', 1.0000, 450.0000, 450.0000, N'', 44),
    (N'wh-cw-045', N'c16a737d8e1347f28917183b77360f1d', 0, N'05', N'Drainage', N'', N'', 0, N'MEC-DRN', N'Make good damaged areas', N'item', 1.0000, 550.0000, 550.0000, N'', 45),
    (N'wh-cw-046', N'c16a737d8e1347f28917183b77360f1d', 0, N'06', N'Brickwork & blockwork', N'', N'', 0, N'WPF-DMP', N'Cavity walls below dpc in two skins of engineering brickwork & lean mix cavity fill', N'm2', 12.0000, 228.0000, 2736.0000, N'', 46),
    (N'wh-cw-047', N'c16a737d8e1347f28917183b77360f1d', 0, N'06', N'Brickwork & blockwork', N'', N'', 0, N'WPF-DMP', N'Damp proof course', N'm', 17.0000, 16.0000, 272.0000, N'', 47),
    (N'wh-cw-048', N'c16a737d8e1347f28917183b77360f1d', 0, N'06', N'Brickwork & blockwork', N'', N'', 0, N'INT-INW', N'Cavity wall in two skins of 100 mm blockwork & 115 mm Kingspan insulation to cavity', N'm2', 6.0000, 188.0000, 1128.0000, N'', 48),
    (N'wh-cw-049', N'c16a737d8e1347f28917183b77360f1d', 0, N'06', N'Brickwork & blockwork', N'', N'', 0, N'MASON-BRK', N'Make good around existing & newley formed openings', N'item', 1.0000, 350.0000, 350.0000, N'', 49),
    (N'wh-cw-050', N'c16a737d8e1347f28917183b77360f1d', 0, N'06', N'Brickwork & blockwork', N'', N'', 0, N'MASON-BRK', N'Wall extension profiles', N'm', 10.0000, 32.0000, 320.0000, N'', 50),
    (N'wh-cw-051', N'c16a737d8e1347f28917183b77360f1d', 0, N'06', N'Brickwork & blockwork', N'', N'', 0, N'MASON-BRK', N'Thermabate cavity closers', N'm', 14.0000, 22.0000, 308.0000, N'', 51),
    (N'wh-cw-052', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'305 x 305 x 97 kg steel beam', N'kg', 780.0000, 7.0000, 5460.0000, N'', 52),
    (N'wh-cw-053', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'D49 mesh wrapped around ground beam', N'item', 1.0000, 550.0000, 550.0000, N'', 53),
    (N'wh-cw-054', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'305 x 305 x 118 kg steel beam', N'kg', 920.0000, 7.0000, 6440.0000, N'', 54),
    (N'wh-cw-055', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'203 x 133 x 25 kg steel beam', N'kg', 75.0000, 7.0000, 525.0000, N'', 55),
    (N'wh-cw-056', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'254 x 146 x 45 kg steel beam', N'kg', 1025.0000, 7.0000, 7175.0000, N'', 56),
    (N'wh-cw-057', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'152 x 152 x 23 kg steel beam', N'kg', 495.0000, 7.0000, 3465.0000, N'', 57),
    (N'wh-cw-058', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'152 x 152 x 37 kg steel beam', N'kg', 950.0000, 7.0000, 6650.0000, N'', 58),
    (N'wh-cw-059', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'254 x 254 x 73 kg steel columns', N'kg', 440.0000, 7.0000, 3080.0000, N'', 59),
    (N'wh-cw-060', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'114.3 CHS 6.3 steel columns', N'kg', 210.0000, 7.0000, 1470.0000, N'', 60),
    (N'wh-cw-061', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'SUB-CON', N'Cut out & cast concrete padstones', N'nr', 5.0000, 95.0000, 475.0000, N'', 61),
    (N'wh-cw-062', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'Base plate & hold down brackets', N'nr', 4.0000, 55.0000, 220.0000, N'', 62),
    (N'wh-cw-063', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'PRELIMS-PRO', N'Fireline protection to steels', N'item', 1.0000, 750.0000, 750.0000, N'', 63),
    (N'wh-cw-064', N'c16a737d8e1347f28917183b77360f1d', 0, N'07', N'Structural steelwork', N'', N'', 0, N'STR-STL', N'Raise existing steel beam in sitting room 2', N'item', 1.0000, 4000.0000, 4000.0000, N'', 64),
    (N'wh-cw-065', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'Timber wall plate bolted to wall', N'm', 28.0000, 36.0000, 1008.0000, N'', 65),
    (N'wh-cw-066', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-CUT', N'50 x 150 mm timber roof joists', N'm', 228.0000, 30.0000, 6840.0000, N'', 66),
    (N'wh-cw-067', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'ROOF-FLT', N'Plywood decking over firings to flat roof', N'm2', 62.0000, 52.0000, 3224.0000, N'', 67),
    (N'wh-cw-068', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'ROOF-FSU', N'Render board to soffit', N'm2', 52.0000, 40.0000, 2080.0000, N'', 68),
    (N'wh-cw-069', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'SUP-KIT', N'50 x 150 mm timber ceiling joists to kitchen', N'm', 88.0000, 30.0000, 2640.0000, N'', 69),
    (N'wh-cw-070', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'50 x 62 mm timber ceiling joists to bathroom', N'm', 28.0000, 26.0000, 728.0000, N'', 70),
    (N'wh-cw-071', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'Joist hangers', N'nr', 142.0000, 7.0000, 994.0000, N'', 71),
    (N'wh-cw-072', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'Galvanised restraint straps', N'nr', 38.0000, 18.0000, 684.0000, N'', 72),
    (N'wh-cw-073', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'6 mm plywood to bedroom 5 floor', N'm2', 28.0000, 18.0000, 504.0000, N'', 73),
    (N'wh-cw-074', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'50 x 100 mm timber internal stud walls', N'm2', 28.0000, 70.0000, 1960.0000, N'', 74),
    (N'wh-cw-075', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-DOR', N'Extra for forming pocket door reveals', N'item', 1.0000, 250.0000, 250.0000, N'', 75),
    (N'wh-cw-076', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'25 x 50 mm timber battens fixed to external walls', N'm2', 92.0000, 48.0000, 4416.0000, N'Omit item V15', 76),
    (N'wh-cw-077', N'c16a737d8e1347f28917183b77360f1d', 0, N'08', N'Carpenter - 1st Fix', N'', N'', 0, N'CARP-1FX', N'18 mm OSB board to battens', N'm2', 92.0000, 34.0000, 3128.0000, N'', 77),
    (N'wh-cw-078', N'c16a737d8e1347f28917183b77360f1d', 0, N'09', N'Insulation & Screed', N'', N'', 0, N'INT-INF', N'100 mm Kingspan floor insulation', N'm2', 46.0000, 44.0000, 2024.0000, N'', 78),
    (N'wh-cw-079', N'c16a737d8e1347f28917183b77360f1d', 0, N'09', N'Insulation & Screed', N'', N'', 0, N'CARP-1FX', N'Vapour control layer', N'm2', 46.0000, 12.0000, 552.0000, N'', 79),
    (N'wh-cw-080', N'c16a737d8e1347f28917183b77360f1d', 0, N'09', N'Insulation & Screed', N'', N'', 0, N'INT-INF', N'70 mm sand / cement screed', N'm2', 46.0000, 60.0000, 2760.0000, N'', 80),
    (N'wh-cw-081', N'c16a737d8e1347f28917183b77360f1d', 0, N'10', N'Roofer', N'', N'', 0, N'ROOF-FLT', N'EPDM flat roof covering', N'm2', 62.0000, 155.0000, 9610.0000, N'', 81),
    (N'wh-cw-082', N'c16a737d8e1347f28917183b77360f1d', 0, N'10', N'Roofer', N'', N'', 0, N'ROOF-RFR', N'Ditto to upstands', N'item', 1.0000, 750.0000, 750.0000, N'', 82),
    (N'wh-cw-083', N'c16a737d8e1347f28917183b77360f1d', 0, N'10', N'Roofer', N'', N'', 0, N'ROOF-LED', N'Lead flashing / valley lining', N'm', 14.0000, 55.0000, 770.0000, N'', 83),
    (N'wh-cw-084', N'c16a737d8e1347f28917183b77360f1d', 0, N'10', N'Roofer', N'', N'', 0, N'ROOF-GRU', N'Aluminium deep guttering', N'm', 44.0000, 78.0000, 3432.0000, N'', 84),
    (N'wh-cw-085', N'c16a737d8e1347f28917183b77360f1d', 0, N'10', N'Roofer', N'', N'', 0, N'ROOF-RFR', N'Ditto rainwater pipework', N'm', 16.0000, 80.0000, 1280.0000, N'', 85),
    (N'wh-cw-086', N'c16a737d8e1347f28917183b77360f1d', 0, N'10', N'Roofer', N'', N'', 0, N'ROOF-RFR', N'Snow Guard', N'item', 1.0000, 1250.0000, 1250.0000, N'', 86),
    (N'wh-cw-087', N'c16a737d8e1347f28917183b77360f1d', 0, N'11', N'Glazier', N'', N'', 0, N'WDR-SPG', N'Supply & fit as per Fluid Glass Quote', N'item', 1.0000, 81913.9500, 81913.9500, N'Omit item V07 (Deposit)', 87),
    (N'wh-cw-088', N'c16a737d8e1347f28917183b77360f1d', 0, N'11', N'Glazier', N'', N'', 0, N'WDR-SPG', N'Main contractors OH&P', N'item', 1.0000, 8191.0000, 8191.0000, N'', 88),
    (N'wh-cw-089', N'c16a737d8e1347f28917183b77360f1d', 0, N'11', N'Glazier', N'', N'', 0, N'WDR-SPG', N'Trickle vents to windows', N'item', 1.0000, 250.0000, 250.0000, N'', 89),
    (N'wh-cw-090', N'c16a737d8e1347f28917183b77360f1d', 0, N'11', N'Glazier', N'', N'', 0, N'WDR-SPG', N'New porch entrance door', N'item', 1.0000, 2500.0000, 2500.0000, N'', 90),
    (N'wh-cw-091', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-BLR', N'Relocate existing boiler into new location', N'nr', 1.0000, 500.0000, 500.0000, N'Omit item V17', 91),
    (N'wh-cw-092', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-PLM', N'Megaflow hot water cylinder', N'nr', 1.0000, 2980.0000, 2980.0000, N'Omit item V17', 92),
    (N'wh-cw-093', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'SUP-KIT', N'Wet underfloor heating to kitchen / dinner', N'm2', 46.0000, 155.0000, 7130.0000, N'Omit item V17', 93),
    (N'wh-cw-094', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-UFH', N'Manifold', N'item', 1.0000, 380.0000, 380.0000, N'Omit item V17', 94),
    (N'wh-cw-095', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-PLM', N'Radiators with TRVs (£225 rad / £25 TRV supply)', N'nr', 13.0000, 455.0000, 5915.0000, N'Omit item V17', 95),
    (N'wh-cw-096', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-DRN', N'Soil vent pipework', N'item', 1.0000, 550.0000, 550.0000, N'Omit item V17', 96),
    (N'wh-cw-097', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'SUP-KIT', N'Hot & cold supplies to kitchen & sanitary fittings', N'nr', 17.0000, 178.0000, 3026.0000, N'Omit item V17', 97),
    (N'wh-cw-098', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-DRN', N'Wastes to ditto', N'nr', 9.0000, 88.0000, 792.0000, N'Omit item V17', 98),
    (N'wh-cw-099', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-PLM', N'External tap', N'nr', 1.0000, 155.0000, 155.0000, N'Omit item V17', 99),
    (N'wh-cw-100', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'SUP-SAN', N'Fix only - Sanitry items to GF WC', N'item', 1.0000, 720.0000, 720.0000, N'Omit item V17', 100),
    (N'wh-cw-101', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-PLM', N'Builders work in connection with plumbing & heating installation', N'item', 1.0000, 500.0000, 500.0000, N'Omit item V17', 101),
    (N'wh-cw-102', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-VNT', N'Bora Extract Ducting within Island', N'item', 1.0000, 850.0000, 850.0000, N'Omit item V17', 102),
    (N'wh-cw-103', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 0, N'MEC-PLM', N'LPG Ducting and Pipework', N'item', 1.0000, 1200.0000, 1200.0000, N'Omit item V17', 103),
    (N'wh-cw-104', N'c16a737d8e1347f28917183b77360f1d', 0, N'12', N'Plumbing & heating', N'', N'', 1, N'MEC-PLM', N'New mains water supply with stop cock - Provisional sum', N'item', 0.0000, 2500.0000, 0.0000, N'', 104),
    (N'wh-cw-105', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'New consumer unit', N'nr', 1.0000, 950.0000, 950.0000, N'Omit item V16', 105),
    (N'wh-cw-106', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Double socket outlet', N'nr', 30.0000, 120.0000, 3600.0000, N'Omit item V16', 106),
    (N'wh-cw-107', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'External double sockets', N'nr', 3.0000, 132.0000, 396.0000, N'Omit item V16', 107),
    (N'wh-cw-108', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Fused spurs', N'nr', 5.0000, 110.0000, 550.0000, N'Omit item V16', 108),
    (N'wh-cw-109', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'TV / data', N'item', 1.0000, 850.0000, 850.0000, N'Omit item V16', 109),
    (N'wh-cw-110', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Smoke/heat detector', N'nr', 4.0000, 145.0000, 580.0000, N'Omit item V16', 110),
    (N'wh-cw-111', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'MEC-UFH', N'Electric underfloor heating to utility, hall & WC', N'm2', 18.0000, 155.0000, 2790.0000, N'Omit item V16', 111),
    (N'wh-cw-112', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Carbon monoixide detector', N'nr', 1.0000, 160.0000, 160.0000, N'Omit item V16', 112),
    (N'wh-cw-113', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'EXTW-FEN', N'Ducting & cabling to fron gate for future use', N'item', 1.0000, 3000.0000, 3000.0000, N'Omit item V16', 113),
    (N'wh-cw-114', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Builders work in connection with electrical installation', N'item', 1.0000, 500.0000, 500.0000, N'Omit item V16', 114),
    (N'wh-cw-115', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Phos recessed downlights - L1,2,3,4,5 & 7', N'nr', 134.0000, 200.0000, 26800.0000, N'Omit item V16', 115),
    (N'wh-cw-116', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Honeycomb louvre - HC', N'nr', 20.0000, 45.0000, 900.0000, N'Omit item V16', 116),
    (N'wh-cw-117', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Astro adjustable downlight 1240028 - L6', N'nr', 10.0000, 92.0000, 920.0000, N'Omit item V16', 117),
    (N'wh-cw-118', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Fix only - Client supplied light fittings', N'nr', 15.0000, 70.0000, 1050.0000, N'Omit item V16', 118),
    (N'wh-cw-119', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Danlers recessed PIR', N'nr', 3.0000, 98.0000, 294.0000, N'Omit item V16', 119),
    (N'wh-cw-120', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'LED shelf light tape, including drivers', N'm', 7.0000, 100.0000, 700.0000, N'Omit item V16', 120),
    (N'wh-cw-121', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'WDR-SPG', N'Phos LED skylight, including drivers', N'm', 37.0000, 125.0000, 4625.0000, N'Omit item V16', 121),
    (N'wh-cw-122', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Lutron RA Keypad - plates / system', N'item', 1.0000, 5000.0000, 5000.0000, N'Omit item V16', 122),
    (N'wh-cw-123', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Light grafix surface mounted spotlight', N'nr', 2.0000, 145.0000, 290.0000, N'Omit item V16', 123),
    (N'wh-cw-124', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Light graphix  wall light', N'nr', 12.0000, 168.0000, 2016.0000, N'Omit item V16', 124),
    (N'wh-cw-125', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Wall mounted PIRs', N'nr', 3.0000, 120.0000, 360.0000, N'Omit item V16', 125),
    (N'wh-cw-126', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Phos recessed step light', N'nr', 9.0000, 245.0000, 2205.0000, N'Omit item V16', 126),
    (N'wh-cw-127', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Wiska junction box', N'nr', 5.0000, 100.0000, 500.0000, N'Omit item V16', 127),
    (N'wh-cw-128', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'External recessed ceilinglights', N'nr', 1.0000, 135.0000, 135.0000, N'Omit item V16', 128),
    (N'wh-cw-129', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Steinal wall light', N'nr', 1.0000, 180.0000, 180.0000, N'Omit item V16', 129),
    (N'wh-cw-130', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'EXTW-FEN', N'Light graphix gate signage', N'nr', 1.0000, 250.0000, 250.0000, N'Omit item V16', 130),
    (N'wh-cw-131', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'CARP-JNR', N'Internal joinery light', N'item', 1.0000, 300.0000, 300.0000, N'Omit item V16', 131),
    (N'wh-cw-132', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'Reading light', N'nr', 2.0000, 122.0000, 244.0000, N'Omit item V16', 132),
    (N'wh-cw-133', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'SB focus 1 x switch', N'nr', 3.0000, 80.0000, 240.0000, N'Omit item V16', 133),
    (N'wh-cw-134', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'SB focus 1 x intermediate switch', N'nr', 4.0000, 85.0000, 340.0000, N'Omit item V16', 134),
    (N'wh-cw-135', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'SB focus 1 x 2 way switch', N'nr', 5.0000, 90.0000, 450.0000, N'Omit item V16', 135),
    (N'wh-cw-136', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'SB focus 2 x 2 way switch', N'nr', 6.0000, 95.0000, 570.0000, N'Omit item V16', 136),
    (N'wh-cw-137', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'SB focus 3 x dimmer', N'nr', 4.0000, 100.0000, 400.0000, N'Omit item V16', 137),
    (N'wh-cw-138', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'SB focus 4 x dimmer', N'nr', 1.0000, 110.0000, 110.0000, N'Omit item V16', 138),
    (N'wh-cw-139', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'5amp socket MK white', N'nr', 18.0000, 100.0000, 1800.0000, N'Omit item V16', 139),
    (N'wh-cw-140', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'MK white 1 x switch', N'nr', 2.0000, 55.0000, 110.0000, N'Omit item V16', 140),
    (N'wh-cw-141', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'ELE-STD', N'5 amp floor socket', N'nr', 1.0000, 180.0000, 180.0000, N'Omit item V16', 141),
    (N'wh-cw-142', N'c16a737d8e1347f28917183b77360f1d', 0, N'13', N'Electrical', N'', N'', 0, N'MEC-VNT', N'Extractor fan', N'nr', 3.0000, 295.0000, 885.0000, N'Omit item V16', 142),
    (N'wh-cw-143', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLS', N'200 mm Kingspan insulation to new extension roof', N'm2', 18.0000, 60.0000, 1080.0000, N'', 143),
    (N'wh-cw-144', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLB', N'12.5mm plasterboard to ceilings', N'm2', 52.0000, 20.0000, 1040.0000, N'', 144),
    (N'wh-cw-145', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLS', N'3 mm skim to ceilings', N'm2', 72.0000, 18.0000, 1296.0000, N'', 145),
    (N'wh-cw-146', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLS', N'Make good existing ceilings as required', N'item', 1.0000, 1500.0000, 1500.0000, N'', 146),
    (N'wh-cw-147', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLB', N'72.5 mm Kingspan plasterboard to walls', N'm2', 92.0000, 68.0000, 6256.0000, N'', 147),
    (N'wh-cw-148', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'CARP-1FX', N'50 mm rockwool insulation between stud walls', N'm2', 28.0000, 14.0000, 392.0000, N'', 148),
    (N'wh-cw-149', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLB', N'12.5 mm plasterboard to blockwork & studs', N'm2', 74.0000, 18.0000, 1332.0000, N'', 149),
    (N'wh-cw-150', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLS', N'3 mm skim to walls', N'm2', 166.0000, 18.0000, 2988.0000, N'', 150),
    (N'wh-cw-151', N'c16a737d8e1347f28917183b77360f1d', 0, N'14', N'Plaster', N'', N'', 0, N'INT-PLS', N'Make good existing walls as required', N'item', 1.0000, 500.0000, 500.0000, N'', 151),
    (N'wh-cw-152', N'c16a737d8e1347f28917183b77360f1d', 0, N'15', N'Render', N'', N'', 0, N'INT-RDR', N'K - render to external walls', N'm2', 20.0000, 155.0000, 3100.0000, N'', 152),
    (N'wh-cw-153', N'c16a737d8e1347f28917183b77360f1d', 0, N'15', N'Render', N'', N'', 0, N'ROOF-FSU', N'Render to soffit', N'm2', 52.0000, 88.0000, 4576.0000, N'', 153),
    (N'wh-cw-154', N'c16a737d8e1347f28917183b77360f1d', 0, N'16', N'Glazing', N'', N'', 0, N'STR-MRL', N'New glazed balustrade to stairs', N'item', 1.0000, 2500.0000, 2500.0000, N'', 154),
    (N'wh-cw-155', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-DOR', N'Internal door lining & panel door', N'nr', 9.0000, 395.0000, 3555.0000, N'Omit item V18 - Door Supply', 155),
    (N'wh-cw-156', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-DOR', N'Internal door lining & glazed door', N'nr', 4.0000, 550.0000, 2200.0000, N'Omit item V18 - Door Supply', 156),
    (N'wh-cw-157', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-DOR', N'Internal door lining & double door', N'nr', 1.0000, 850.0000, 850.0000, N'Omit item V18 - Door Supply', 157),
    (N'wh-cw-158', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-DOR', N'Sliding pocket door system', N'nr', 2.0000, 498.0000, 996.0000, N'', 158),
    (N'wh-cw-159', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'SUP-IRO', N'Supply of ironmongery', N'nr', 17.0000, 150.0000, 2550.0000, N'Omit item V18', 159),
    (N'wh-cw-160', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-2FX', N'Fix only ironmonery', N'nr', 17.0000, 80.0000, 1360.0000, N'', 160),
    (N'wh-cw-161', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-2FX', N'MDF architraves to new door frames', N'm', 155.0000, 14.0000, 2170.0000, N'', 161),
    (N'wh-cw-162', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-2FX', N'MDF skirting to walls to new walls (£8/m supply)', N'm', 78.0000, 28.0000, 2184.0000, N'', 162),
    (N'wh-cw-163', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-2FX', N'MDF window boards', N'm', 8.0000, 36.0000, 288.0000, N'', 163),
    (N'wh-cw-164', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-1FX', N'Plywood boxing to internal pipework', N'item', 1.0000, 500.0000, 500.0000, N'', 164),
    (N'wh-cw-165', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'CARP-1FX', N'Loft access hatch with drop down ladder', N'nr', 1.0000, 775.0000, 775.0000, N'Omit item V02', 165),
    (N'wh-cw-166', N'c16a737d8e1347f28917183b77360f1d', 0, N'17', N'Carpenter - 2nd Fix', N'', N'', 0, N'SUP-KIT', N'Kitchen & utility installation coordination', N'item', 1.0000, 500.0000, 500.0000, N'', 166),
    (N'wh-cw-167', N'c16a737d8e1347f28917183b77360f1d', 0, N'18', N'Wall tiling & floor finishes', N'', N'', 0, N'SUP-TIL', N'Floor tiling supply (£60/m)', N'm2', 65.0000, 60.0000, 3900.0000, N'', 167),
    (N'wh-cw-168', N'c16a737d8e1347f28917183b77360f1d', 0, N'18', N'Wall tiling & floor finishes', N'', N'', 0, N'SUP-TIL', N'Wall tiling to splash backs (£60/m supply)', N'm2', 4.0000, 60.0000, 240.0000, N'', 168),
    (N'wh-cw-169', N'c16a737d8e1347f28917183b77360f1d', 0, N'18', N'Wall tiling & floor finishes', N'', N'', 0, N'TIL-STD', N'Fix only - Wall tiles', N'm2', 4.0000, 80.0000, 320.0000, N'', 169),
    (N'wh-cw-170', N'c16a737d8e1347f28917183b77360f1d', 0, N'18', N'Wall tiling & floor finishes', N'', N'', 0, N'TIL-STD', N'Ditra matting', N'm2', 65.0000, 34.0000, 2210.0000, N'', 170),
    (N'wh-cw-171', N'c16a737d8e1347f28917183b77360f1d', 0, N'18', N'Wall tiling & floor finishes', N'', N'', 0, N'TIL-STD', N'Fix only - Floor tiles', N'm2', 65.0000, 80.0000, 5200.0000, N'', 171),
    (N'wh-cw-172', N'c16a737d8e1347f28917183b77360f1d', 0, N'19', N'Painter & decorator (to new / altered areas)', N'', N'', 0, N'DEC-STD', N'Mist & 2 coats of Dulux emulsion to ceilings', N'm2', 272.0000, 16.0000, 4352.0000, N'', 172),
    (N'wh-cw-173', N'c16a737d8e1347f28917183b77360f1d', 0, N'19', N'Painter & decorator (to new / altered areas)', N'', N'', 0, N'DEC-STD', N'Ditto walls', N'm2', 498.0000, 14.0000, 6972.0000, N'', 173),
    (N'wh-cw-174', N'c16a737d8e1347f28917183b77360f1d', 0, N'19', N'Painter & decorator (to new / altered areas)', N'', N'', 0, N'WDR-TIM', N'Prepare & decorate doors', N'm2', 36.0000, 30.0000, 1080.0000, N'', 174),
    (N'wh-cw-175', N'c16a737d8e1347f28917183b77360f1d', 0, N'19', N'Painter & decorator (to new / altered areas)', N'', N'', 0, N'CARP-2FX', N'Frames, architrave, window board & skirtings', N'm', 312.0000, 8.0000, 2496.0000, N'', 175),
    (N'wh-cw-176', N'c16a737d8e1347f28917183b77360f1d', 0, N'19', N'Painter & decorator (to new / altered areas)', N'', N'', 0, N'DEC-STD', N'External decoration as required', N'item', 1.0000, 1500.0000, 1500.0000, N'', 176),
    (N'wh-cw-177', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-EXC', N'Excavate to reduce levels & remove spoil', N'm3', 18.0000, 110.0000, 1980.0000, N'', 177),
    (N'wh-cw-178', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-EXC', N'Excavate foundations (various sizes) & remove spoil', N'm3', 32.0000, 145.0000, 4640.0000, N'', 178),
    (N'wh-cw-179', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-CON', N'Concrete in foundations', N'm3', 24.0000, 170.0000, 4080.0000, N'', 179),
    (N'wh-cw-180', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'EXTW-PAV', N'Paving slabs patio (£60/m supply)', N'm2', 108.0000, 60.0000, 6480.0000, N'', 180),
    (N'wh-cw-181', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'EXTW-PAV', N'Fix only - Paving slabs', N'm2', 108.0000, 115.0000, 12420.0000, N'', 181),
    (N'wh-cw-182', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-CON', N'Hollow block wall with concrete & reinforcement', N'm2', 48.0000, 180.0000, 8640.0000, N'', 182),
    (N'wh-cw-183', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-GWK', N'Stone cladding to retaining wall (top half only)', N'm2', 28.0000, 198.0000, 5544.0000, N'', 183),
    (N'wh-cw-184', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'MASON-STN', N'Stone round edge cill to retaining wall', N'm', 68.0000, 120.0000, 8160.0000, N'', 184),
    (N'wh-cw-185', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-CON', N'Form & cast concrete steps', N'item', 1.0000, 6245.0000, 6245.0000, N'', 185),
    (N'wh-cw-186', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'SUB-GWK', N'Widen entrance & grade land for access', N'item', 1.0000, 1500.0000, 1500.0000, N'', 186),
    (N'wh-cw-187', N'c16a737d8e1347f28917183b77360f1d', 0, N'20', N'External works', N'', N'', 0, N'EXTW-LND', N'Make good on completion', N'item', 1.0000, 500.0000, 500.0000, N'', 187)
) AS source (ValuationLineItemId, ProjectId, ElementType, SectionCode, SectionName,
             VariationRef, VariationTitle, LineType, CostCode, Description, Unit,
             Quantity, Rate, LineAmount, Comments, DisplayOrder)
ON target.ValuationLineItemId = source.ValuationLineItemId
WHEN MATCHED THEN UPDATE SET
    ProjectId      = source.ProjectId,
    ElementType    = source.ElementType,
    SectionCode    = source.SectionCode,
    SectionName    = source.SectionName,
    VariationRef   = source.VariationRef,
    VariationTitle = source.VariationTitle,
    LineType       = source.LineType,
    CostCode       = source.CostCode,
    Description    = source.Description,
    Unit           = source.Unit,
    Quantity       = source.Quantity,
    Rate           = source.Rate,
    LineAmount     = source.LineAmount,
    Comments       = source.Comments,
    DisplayOrder   = source.DisplayOrder
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ValuationLineItemId, ProjectId, ElementType, SectionCode, SectionName,
            VariationRef, VariationTitle, LineType, CostCode, Description, Unit,
            Quantity, Rate, LineAmount, Comments, DisplayOrder)
    VALUES (source.ValuationLineItemId, source.ProjectId, source.ElementType,
            source.SectionCode, source.SectionName, source.VariationRef,
            source.VariationTitle, source.LineType, source.CostCode,
            source.Description, source.Unit, source.Quantity, source.Rate,
            source.LineAmount, source.Comments, source.DisplayOrder);
GO

-- Sanity check: the seeded block should reconcile to the workbook.
SELECT
    SUM(LineAmount) AS ContractSum   -- 536040.95
FROM [dbo].[ValuationLineItems]
WHERE ProjectId = N'c16a737d8e1347f28917183b77360f1d' AND ElementType = 0
  AND LineType NOT IN (3, 4);
GO
