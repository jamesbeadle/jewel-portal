-- ============================================================================
-- Seed the master admin: james.beadle@jewelbb.co.uk
-- ----------------------------------------------------------------------------
-- Run this against the Azure SQL database AFTER the AddLocalAuth migration has
-- created the UserCredentials table (the app auto-migrates on startup).
--
-- Idempotent: safe to run more than once. It inserts the row if missing and
-- refreshes the password hash + status if it already exists.
--
-- James is also listed in JpmsAdministrators in code, so he is granted every
-- role automatically — no DirectoryUserRoles rows are required for him.
--
-- Login password (give this to James, then he can change it later via a reset):
--     1HZcs3VymQlU2ugMn6tJ
-- ============================================================================

DECLARE @Email        nvarchar(256) = N'james.beadle@jewelbb.co.uk';
DECLARE @DisplayName  nvarchar(256) = N'James Beadle';
DECLARE @PasswordHash nvarchar(512) = N'v1.pbkdf2-sha256.210000.7IgtzMXjsNKxL+QHB5Wrdw==.SIRmX2ZPVju/FgmxLxIR5lABkHWc2EZt+5gRJ9IjiIU=';
DECLARE @Now          datetimeoffset = SYSDATETIMEOFFSET();

-- Directory entry (name shown in the UI) ------------------------------------
IF EXISTS (SELECT 1 FROM [DirectoryUsers] WHERE [Email] = @Email)
    UPDATE [DirectoryUsers] SET [DisplayName] = @DisplayName WHERE [Email] = @Email;
ELSE
    INSERT INTO [DirectoryUsers] ([Email], [DisplayName]) VALUES (@Email, @DisplayName);

-- Credential (enables password login), set ACTIVE with the seeded hash -------
-- Status: 0 = Invited, 1 = Active, 2 = Disabled
IF EXISTS (SELECT 1 FROM [UserCredentials] WHERE [Email] = @Email)
    UPDATE [UserCredentials]
       SET [PasswordHash]   = @PasswordHash,
           [Status]         = 1,
           [FailedAttempts] = 0,
           [LockedUntil]    = NULL,
           [PasswordSetAt]  = @Now
     WHERE [Email] = @Email;
ELSE
    INSERT INTO [UserCredentials]
        ([Email], [PasswordHash], [Status], [FailedAttempts], [LockedUntil], [CreatedAt], [PasswordSetAt])
    VALUES
        (@Email, @PasswordHash, 1, 0, NULL, @Now, @Now);

SELECT [Email], [Status], [PasswordSetAt] FROM [UserCredentials] WHERE [Email] = @Email;
