using Jewel.JPMS.Api.Cqrs;
using Jewel.JPMS.Api.Gates;
using Jewel.JPMS.Contracts.Cqrs;
using Jewel.JPMS.Contracts.Progress;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;

namespace Jewel.JPMS.Api.Features.Progress.Commands;

public sealed class DeleteProgressPhotoEndpoint
{
    private readonly SignedInUserResolver users;
    private readonly DeleteProgressPhotoAuthorisation authorisation;
    private readonly ICommandHandler<DeleteProgressPhoto, Acknowledgement> handler;

    public DeleteProgressPhotoEndpoint(
        SignedInUserResolver users,
        DeleteProgressPhotoAuthorisation authorisation,
        ICommandHandler<DeleteProgressPhoto, Acknowledgement> handler)
    {
        this.users = users;
        this.authorisation = authorisation;
        this.handler = handler;
    }

    [Function(nameof(DeleteProgressPhoto))]
    public async Task<IActionResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "progress-updates/{progressUpdateId}/photos/{progressPhotoId}")] HttpRequest request,
        string progressUpdateId, string progressPhotoId)
    {
        var signedInUser = await users.ResolveAsync(request, request.HttpContext.RequestAborted);
        if (signedInUser is null) return new UnauthorizedResult();

        var command = new DeleteProgressPhoto(progressUpdateId, progressPhotoId);
        if (!authorisation.Allows(signedInUser, command)) return new StatusCodeResult(403);

        var acknowledgement = await handler.HandleAsync(command, request.HttpContext.RequestAborted);
        return new OkObjectResult(acknowledgement);
    }
}
