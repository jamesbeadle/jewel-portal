using Jewel.JPMS.Contracts.Requests;
using Jewel.JPMS.Cqrs;
using Jewel.JPMS.Features.Requests;
using Jewel.JPMS.Models;

namespace Jewel.JPMS.Services;

public sealed class HttpRequestRegister : IRequestRegister
{
    private readonly RequestsReadModel readModel;
    private readonly IQueryClient queries;
    private readonly ICommandSender commands;

    // Projects whose requests have had a load started — prevents an empty result
    // from re-triggering a fetch on every re-render (see HttpDrawingStore).
    private readonly HashSet<string> requested = new();

    public HttpRequestRegister(RequestsReadModel readModel, IQueryClient queries, ICommandSender commands)
    {
        this.readModel = readModel;
        this.queries = queries;
        this.commands = commands;
        readModel.OnChanged += () => OnChange?.Invoke();
    }

    public event Action? OnChange;

    public IReadOnlyList<Request> ForProject(string projectId)
    {
        if (requested.Add(projectId)) _ = LoadAsync(projectId);
        return readModel.Current(projectId);
    }

    private async Task LoadAsync(string projectId)
    {
        try { await readModel.RefreshAsync(projectId, CancellationToken.None); }
        catch { requested.Remove(projectId); }
    }

    // Forces a background reload even when the project is already cached. Pages call this once
    // on entry (never from render) so tab navigation picks up changes made elsewhere — another
    // user, an agent, or a mutation through a different store.
    public void Refresh(string projectId)
    {
        requested.Add(projectId);
        _ = LoadAsync(projectId);
    }

    public IReadOnlyList<Request> ForProject(string projectId, RequestType kind) =>
        ForProject(projectId).Where(record => record.Kind == kind).ToList().AsReadOnly();

    public Request Upsert(Request record)
    {
        if (string.IsNullOrEmpty(record.RequestId))
            _ = RaiseRecordAsync(record);
        else
            _ = UpdateRecordAsync(record);
        return record;
    }

    public Task<Request?> GetAsync(string requestId, CancellationToken cancellationToken = default) =>
        queries.AskAsync(new GetRequestById(requestId), cancellationToken);

    public async Task<Request> RaiseAsync(RaiseRequest command, CancellationToken cancellationToken = default)
    {
        var raised = await commands.SendAsync(command, cancellationToken);
        await readModel.RefreshAsync(command.ProjectId, cancellationToken);
        return raised;
    }

    public async Task<Request> UpdateAsync(UpdateRequestDetails command, CancellationToken cancellationToken = default)
    {
        var updated = await commands.SendAsync(command, cancellationToken);
        await readModel.RefreshAsync(updated.ProjectId, cancellationToken);
        return updated;
    }

    public Task<IReadOnlyList<RequestMessage>> ListMessagesAsync(string requestId, CancellationToken cancellationToken = default) =>
        queries.AskAsync(new ListRequestMessages(requestId), cancellationToken);

    public Task<MailboxMessageDetail> GetEmailDetailAsync(string requestId, string mailboxId, string? internetMessageId, CancellationToken cancellationToken = default) =>
        queries.AskAsync(new GetRequestEmailDetail(requestId, mailboxId, internetMessageId), cancellationToken);

    public Task<RequestMessage> PostMessageAsync(PostRequestMessage command, CancellationToken cancellationToken = default) =>
        commands.SendAsync(command, cancellationToken);

    public async Task<Request> MergeAsync(string survivorRequestId, string mergedRequestId, string projectId, CancellationToken cancellationToken = default)
    {
        var survivor = await commands.SendAsync(new MergeRequests(survivorRequestId, mergedRequestId), cancellationToken);
        await readModel.RefreshAsync(projectId, cancellationToken);
        return survivor;
    }

    public async Task DeleteAsync(string requestId, string projectId, CancellationToken cancellationToken = default)
    {
        await commands.SendAsync(new DeleteRequest(requestId), cancellationToken);
        await readModel.RefreshAsync(projectId, cancellationToken);
    }

    public async Task ReturnToTriageAsync(string requestId, string projectId, CancellationToken cancellationToken = default)
    {
        await commands.SendAsync(new ReturnRequestToTriage(requestId), cancellationToken);
        await readModel.RefreshAsync(projectId, cancellationToken);
    }

    public Task<IReadOnlyList<Request>> ListUnassignedAsync(CancellationToken cancellationToken = default) =>
        queries.AskAsync(new ListUnassignedRequests(), cancellationToken);

    public async Task<Request> PromoteToRfiAsync(string requestId, string projectId, CancellationToken cancellationToken = default)
    {
        var updated = await commands.SendAsync(new PromoteRequestToRfi(requestId), cancellationToken);
        await readModel.RefreshAsync(projectId, cancellationToken);
        return updated;
    }

    public async Task<Request> EnableRfqAsync(string requestId, string projectId, CancellationToken cancellationToken = default)
    {
        var updated = await commands.SendAsync(new EnableRfqOnRequest(requestId), cancellationToken);
        await readModel.RefreshAsync(projectId, cancellationToken);
        return updated;
    }

    public async Task<Request> LinkToPartyAsync(string requestId, PartyKind partyKind, string? partyId, string? onBehalfOfClientId, string projectId, CancellationToken cancellationToken = default)
    {
        var updated = await commands.SendAsync(new LinkRequestToParty(requestId, partyKind, partyId, onBehalfOfClientId), cancellationToken);
        await readModel.RefreshAsync(projectId, cancellationToken);
        return updated;
    }

    public Task<Request> SaveFormAsync(UpdateRequestForm command, CancellationToken cancellationToken = default) =>
        commands.SendAsync(command, cancellationToken);

    public Task<RequestEmailDraft> PrepareEmailDraftAsync(string requestId, string? recipientOverride = null, CancellationToken cancellationToken = default) =>
        commands.SendAsync(new PrepareRequestEmailDraft(requestId, recipientOverride), cancellationToken);

    public Task<RequestEmailDraft> PrepareReplyDraftAsync(string requestId, string mailboxMessageId, CancellationToken cancellationToken = default) =>
        commands.SendAsync(new PrepareRequestReplyDraft(requestId, mailboxMessageId), cancellationToken);

    // The api caps each call (PDF render + Graph call per draft must fit one function
    // invocation), so larger selections go up in chunks and the outcomes merge back into a
    // single batch — callers see one result however many round trips it took.
    private const int DraftChunkSize = 10;

    public async Task<RequestEmailDraftBatch> PrepareEmailDraftsAsync(IReadOnlyList<string> requestIds, CancellationToken cancellationToken = default)
    {
        var outcomes = new List<RequestEmailDraftOutcome>(requestIds.Count);
        foreach (var chunk in requestIds.Chunk(DraftChunkSize))
        {
            var batch = await commands.SendAsync(new PrepareRequestEmailDrafts(chunk), cancellationToken);
            outcomes.AddRange(batch.Outcomes);
        }
        return new RequestEmailDraftBatch(outcomes);
    }

    private async Task RaiseRecordAsync(Request record)
    {
        await commands.SendAsync(new RaiseRequest(record.ProjectId, record.Kind, record.Reference, record.Title, record.Description, record.Value, record.RaisedByEmail, record.RaisedTo, record.DrawingRef, record.ResponseDue, record.InternalNotes, record.ClientNotes, RaisedToContactId: record.RaisedToContactId), CancellationToken.None);
        await readModel.RefreshAsync(record.ProjectId, CancellationToken.None);
    }

    private async Task UpdateRecordAsync(Request record)
    {
        await commands.SendAsync(new UpdateRequestDetails(record.RequestId, record.Reference, record.Title, record.Description, record.Status, record.Value, record.ResponseText, record.RespondedByEmail, record.ImpliesVariation, record.RaisedTo, record.DrawingRef, record.ResponseDue, record.RelatedDrawingSpec, record.InternalNotes, record.ClientNotes, RaisedToContactId: record.RaisedToContactId), CancellationToken.None);
        await readModel.RefreshAsync(record.ProjectId, CancellationToken.None);
    }
}
