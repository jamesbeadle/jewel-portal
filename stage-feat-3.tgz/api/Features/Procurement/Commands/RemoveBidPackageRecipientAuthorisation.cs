using Jewel.JPMS.Api.Gates;
using Jewel.JPMS.Contracts.Procurement;

namespace Jewel.JPMS.Api.Features.Procurement.Commands;

public sealed class RemoveBidPackageRecipientAuthorisation
{
    private static readonly RoleSet RolesThatMayManageRecipients =
        RoleSet.Of(JpmsRoles.Director, JpmsRoles.ProjectManager, JpmsRoles.OfficeComplianceCoordinator, JpmsRoles.OfficeAdmin);

    public bool Allows(SignedInUser user, RemoveBidPackageRecipient command) => RolesThatMayManageRecipients.IncludesAny(user.Roles);
}
