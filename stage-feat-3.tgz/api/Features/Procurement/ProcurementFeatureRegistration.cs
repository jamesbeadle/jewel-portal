using Jewel.JPMS.Api.Cqrs;
using Jewel.JPMS.Api.Features.Procurement.Attachments;
using Jewel.JPMS.Api.Features.Procurement.Commands;
using Jewel.JPMS.Api.Features.Procurement.Queries;
using Jewel.JPMS.Contracts.Procurement;
using Jewel.JPMS.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Jewel.JPMS.Api.Features.Procurement;

public static class ProcurementFeatureRegistration
{
    public static IServiceCollection AddProcurementFeature(this IServiceCollection services, IConfiguration configuration)
    {
        RegisterAttachmentStore(services, configuration);
        RegisterBidPackageAttachmentStore(services, configuration);

        // Attachments kept on a work order for record keeping (never sent to the supplier).
        services.AddScoped<IQueryHandler<ListWorkOrderAttachments, IReadOnlyList<WorkOrderAttachment>>,
            ListWorkOrderAttachmentsHandler>();
        services.AddScoped<ICommandHandler<RemoveWorkOrderAttachment, IReadOnlyList<WorkOrderAttachment>>,
            RemoveWorkOrderAttachmentHandler>();

        // Tender-document attachments on a bid package (supplier-facing — they travel with the
        // invite draft alongside the linked drawings).
        services.AddScoped<IQueryHandler<ListBidPackageAttachments, IReadOnlyList<BidPackageAttachment>>,
            ListBidPackageAttachmentsHandler>();
        services.AddScoped<ICommandHandler<RemoveBidPackageAttachment, IReadOnlyList<BidPackageAttachment>>,
            RemoveBidPackageAttachmentHandler>();

        services.AddScoped<IQueryHandler<ListBidPackagesForProject, IReadOnlyList<BidPackage>>, ListBidPackagesForProjectHandler>();
        services.AddScoped<IQueryHandler<GetBidPackageById, BidPackage?>, GetBidPackageByIdHandler>();
        services.AddScoped<IQueryHandler<ListQuotesForBidPackage, IReadOnlyList<Quote>>, ListQuotesForBidPackageHandler>();
        services.AddScoped<IQueryHandler<ListProjectWorkOrders, IReadOnlyList<ProjectWorkOrderDetail>>, ListProjectWorkOrdersHandler>();
        services.AddScoped<IQueryHandler<ListBidPackageRecipients, IReadOnlyList<BidPackageRecipient>>, ListBidPackageRecipientsHandler>();
        services.AddScoped<IQueryHandler<ListBidPackageLineItems, IReadOnlyList<BidPackageLineItem>>, ListBidPackageLineItemsHandler>();
        services.AddScoped<IQueryHandler<ListBidPackageEmails, IReadOnlyList<MailboxMessage>>, ListBidPackageEmailsHandler>();
        services.AddScoped<IQueryHandler<ListQuoteLineItemsForBidPackage, IReadOnlyList<QuoteLineItem>>, ListQuoteLineItemsForBidPackageHandler>();
        services.AddScoped<IQueryHandler<ListBidPackageDrawings, IReadOnlyList<Drawing>>, ListBidPackageDrawingsHandler>();
        services.AddScoped<IQueryHandler<SearchLocalSubcontractors, LocalSubcontractorSearchResult>, SearchLocalSubcontractorsHandler>();

        services.AddScoped<ICommandHandler<CreateBidPackage, BidPackage>, CreateBidPackageHandler>();
        services.AddScoped<CreateBidPackageAuthorisation>();
        services.AddScoped<CreateBidPackageValidation>();

        services.AddScoped<ICommandHandler<CreateBidPackageFromMessage, BidPackage>, CreateBidPackageFromMessageHandler>();
        services.AddScoped<CreateBidPackageFromMessageAuthorisation>();
        services.AddScoped<CreateBidPackageFromMessageValidation>();

        services.AddScoped<ICommandHandler<InviteSubcontractorsToBidPackage, IReadOnlyList<BidPackageRecipient>>, InviteSubcontractorsToBidPackageHandler>();
        services.AddScoped<InviteSubcontractorsToBidPackageAuthorisation>();
        services.AddScoped<InviteSubcontractorsToBidPackageValidation>();

        services.AddScoped<ICommandHandler<RemoveBidPackageRecipient, IReadOnlyList<BidPackageRecipient>>, RemoveBidPackageRecipientHandler>();
        services.AddScoped<RemoveBidPackageRecipientAuthorisation>();
        services.AddScoped<RemoveBidPackageRecipientValidation>();

        services.AddScoped<ICommandHandler<DeclineBidPackageRecipient, IReadOnlyList<BidPackageRecipient>>, DeclineBidPackageRecipientHandler>();
        services.AddScoped<DeclineBidPackageRecipientAuthorisation>();
        services.AddScoped<DeclineBidPackageRecipientValidation>();

        services.AddScoped<ICommandHandler<SetBidPackageLineItems, IReadOnlyList<BidPackageLineItem>>, SetBidPackageLineItemsHandler>();
        services.AddScoped<SetBidPackageLineItemsAuthorisation>();
        services.AddScoped<SetBidPackageLineItemsValidation>();

        services.AddScoped<ICommandHandler<AddBidPackageLineItems, IReadOnlyList<BidPackageLineItem>>, AddBidPackageLineItemsHandler>();
        services.AddScoped<AddBidPackageLineItemsAuthorisation>();
        services.AddScoped<AddBidPackageLineItemsValidation>();

        services.AddScoped<ICommandHandler<SetBidPackageLineItemCoverage, IReadOnlyList<BidPackageLineItem>>, SetBidPackageLineItemCoverageHandler>();
        services.AddScoped<SetBidPackageLineItemCoverageAuthorisation>();
        services.AddScoped<SetBidPackageLineItemCoverageValidation>();

        services.AddScoped<ICommandHandler<UpdateBidPackageScope, BidPackage>, UpdateBidPackageScopeHandler>();
        services.AddScoped<UpdateBidPackageScopeAuthorisation>();
        services.AddScoped<UpdateBidPackageScopeValidation>();

        // Ends the tender without a winner / puts it back in play. No reason is captured — closing
        // without incident needs no paperwork.
        services.AddScoped<ICommandHandler<CloseBidPackage, BidPackage>, CloseBidPackageHandler>();
        services.AddScoped<CloseBidPackageAuthorisation>();
        services.AddScoped<CloseBidPackageValidation>();

        services.AddScoped<ICommandHandler<ReopenBidPackage, BidPackage>, ReopenBidPackageHandler>();
        services.AddScoped<ReopenBidPackageAuthorisation>();
        services.AddScoped<ReopenBidPackageValidation>();

        services.AddScoped<ICommandHandler<SetBidPackageDrawings, IReadOnlyList<Drawing>>, SetBidPackageDrawingsHandler>();
        services.AddScoped<SetBidPackageDrawingsAuthorisation>();
        services.AddScoped<SetBidPackageDrawingsValidation>();

        // NOTE: there is deliberately no send-invite command — invites are only ever created as
        // mailbox drafts (PrepareBidPackageInviteDraft) for a human to review and send from Outlook.
        services.AddScoped<ICommandHandler<PrepareBidPackageInviteDraft, BidPackageInviteDraft>, PrepareBidPackageInviteDraftHandler>();
        services.AddScoped<PrepareBidPackageInviteDraftAuthorisation>();
        services.AddScoped<PrepareBidPackageInviteDraftValidation>();

        // Same review-then-send-from-Outlook convention as the invite draft above.
        services.AddScoped<ICommandHandler<PrepareWorkOrderEmailDraft, WorkOrderEmailDraft>, PrepareWorkOrderEmailDraftHandler>();
        services.AddScoped<PrepareWorkOrderEmailDraftAuthorisation>();
        services.AddScoped<PrepareWorkOrderEmailDraftValidation>();

        // The automatic counterpart: SENDS the purchase-order email the moment an order is
        // released (created un-drafted, or a draft approved) — the UI warns before firing it.
        services.AddScoped<ICommandHandler<SendWorkOrderPoEmail, WorkOrderPoEmailOutcome>, SendWorkOrderPoEmailHandler>();
        services.AddScoped<SendWorkOrderPoEmailAuthorisation>();
        services.AddScoped<SendWorkOrderPoEmailValidation>();

        services.AddScoped<ICommandHandler<SaveExtractedQuote, Quote>, SaveExtractedQuoteHandler>();
        services.AddScoped<SaveExtractedQuoteAuthorisation>();
        services.AddScoped<SaveExtractedQuoteValidation>();

        services.AddScoped<ICommandHandler<SubmitQuoteForBidPackage, Quote>, SubmitQuoteForBidPackageHandler>();
        services.AddScoped<SubmitQuoteForBidPackageAuthorisation>();
        services.AddScoped<SubmitQuoteForBidPackageValidation>();

        services.AddScoped<ICommandHandler<ReviseQuote, Quote>, ReviseQuoteHandler>();
        services.AddScoped<ReviseQuoteAuthorisation>();
        services.AddScoped<ReviseQuoteValidation>();

        services.AddScoped<ICommandHandler<AwardBidPackage, WorkOrder>, AwardBidPackageHandler>();
        services.AddScoped<AwardBidPackageAuthorisation>();
        services.AddScoped<AwardBidPackageValidation>();

        services.AddScoped<ICommandHandler<IssueWorkOrderForVariationOrder, WorkOrder>, IssueWorkOrderForVariationOrderHandler>();

        services.AddScoped<ICommandHandler<UpdateWorkOrder, WorkOrder>, UpdateWorkOrderHandler>();
        services.AddScoped<UpdateWorkOrderAuthorisation>();
        services.AddScoped<UpdateWorkOrderValidation>();

        services.AddScoped<ICommandHandler<RecodeWorkOrderLine, IReadOnlyList<WorkOrderLine>>, RecodeWorkOrderLineHandler>();
        services.AddScoped<RecodeWorkOrderLineAuthorisation>();
        services.AddScoped<RecodeWorkOrderLineValidation>();

        services.AddScoped<ICommandHandler<CreateManualWorkOrder, WorkOrder>, CreateManualWorkOrderHandler>();
        services.AddScoped<CreateManualWorkOrderAuthorisation>();
        services.AddScoped<CreateManualWorkOrderValidation>();

        // The Control Centre's "create new work order from this email" — the manual-order
        // handler wrapped with the email link, mirroring CreateBidPackageFromMessage.
        services.AddScoped<ICommandHandler<CreateWorkOrderFromMessage, WorkOrder>, CreateWorkOrderFromMessageHandler>();
        services.AddScoped<CreateWorkOrderFromMessageAuthorisation>();
        services.AddScoped<CreateWorkOrderFromMessageValidation>();

        services.AddScoped<ICommandHandler<UpdateManualWorkOrder, WorkOrder>, UpdateManualWorkOrderHandler>();
        services.AddScoped<UpdateManualWorkOrderAuthorisation>();
        services.AddScoped<UpdateManualWorkOrderValidation>();

        services.AddScoped<ICommandHandler<ApproveWorkOrder, WorkOrder>, ApproveWorkOrderHandler>();
        services.AddScoped<ApproveWorkOrderAuthorisation>();
        services.AddScoped<ApproveWorkOrderValidation>();

        services.AddScoped<ICommandHandler<RejectWorkOrder, WorkOrder>, RejectWorkOrderHandler>();
        services.AddScoped<RejectWorkOrderAuthorisation>();
        services.AddScoped<RejectWorkOrderValidation>();

        return services;
    }

    // Work-order attachments share the drawings storage account by default — one connection string
    // to configure, one backup story — but can be pointed at their own account if volume ever
    // warrants it. Same chain as the request attachment store.
    private static void RegisterAttachmentStore(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration["WorkOrderAttachmentsStorage:ConnectionString"]
            ?? configuration["DrawingsStorage:ConnectionString"]
            ?? configuration["AzureWebJobsStorage"];

        if (string.IsNullOrWhiteSpace(connectionString))
            services.AddSingleton<IWorkOrderAttachmentStore, NullWorkOrderAttachmentStore>();
        else
            services.AddSingleton<IWorkOrderAttachmentStore>(
                _ => new AzureBlobWorkOrderAttachmentStore(connectionString));
    }

    // Bid-package attachments follow the same chain, with their own key first so they can be
    // split onto a different account if tender-document volume ever warrants it.
    private static void RegisterBidPackageAttachmentStore(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration["BidPackageAttachmentsStorage:ConnectionString"]
            ?? configuration["DrawingsStorage:ConnectionString"]
            ?? configuration["AzureWebJobsStorage"];

        if (string.IsNullOrWhiteSpace(connectionString))
            services.AddSingleton<Attachments.IBidPackageAttachmentStore, Attachments.NullBidPackageAttachmentStore>();
        else
            services.AddSingleton<Attachments.IBidPackageAttachmentStore>(
                _ => new Attachments.AzureBlobBidPackageAttachmentStore(connectionString));
    }
}
