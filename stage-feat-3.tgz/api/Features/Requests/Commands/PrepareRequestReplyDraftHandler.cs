using Jewel.JPMS.Api.Cqrs;
using Jewel.JPMS.Api.Data;
using Jewel.JPMS.Api.Features.MailboxIntake.Graph;
using Jewel.JPMS.Api.Features.Requests.Documents;
using Jewel.JPMS.Contracts.Requests;
using Jewel.JPMS.Models;
using Microsoft.EntityFrameworkCore;

namespace Jewel.JPMS.Api.Features.Requests.Commands;

/// <summary>
/// Creates an Outlook draft REPLY to an email already linked to the request, carrying the freshly
/// rendered official document PDF. Graph's createReplyAll keeps the reply in the original
/// conversation — "RE:" subject, thread headers, quoted history, original recipients — and the
/// branded cover note is placed above the quoted history, so the formal document arrives inside the
/// email chain it relates to. The draft is tagged with the request's workflow category so the sent
/// copy and its replies group under the request in triage. Nothing is sent — a person reviews,
/// adjusts recipients if needed, and sends from the mailbox itself — but as with the fresh-email
/// draft, an Open request moves to Awaiting Response the moment the document is drafted; the team
/// manually sets it back to Open if the send is cancelled.
/// </summary>
public sealed class PrepareRequestReplyDraftHandler : ICommandHandler<PrepareRequestReplyDraft, RequestEmailDraft>
{
    private readonly JpmsContext context;
    private readonly IMailboxGraphClient graph;
    private readonly Audit.AuditTrail audit;

    public PrepareRequestReplyDraftHandler(JpmsContext context, IMailboxGraphClient graph, Audit.AuditTrail audit)
    {
        this.context = context;
        this.graph = graph;
        this.audit = audit;
    }

    public async Task<RequestEmailDraft> HandleAsync(PrepareRequestReplyDraft command, CancellationToken cancellationToken)
    {
        var request = await context.Requests
            .FirstOrDefaultAsync(r => r.RequestId == command.RequestId, cancellationToken);
        if (request is null) throw new InvalidOperationException($"Request '{command.RequestId}' not found.");

        // EMAIL POLICY: the official document only exists at the official stage (RFI / NOD / EOT),
        // so only those kinds can be replied with it attached.
        var kind = (RequestType)request.Kind;
        if (!kind.IsEmailable())
            throw new InvalidOperationException(
                $"A {kind.DisplayName()} request has no official document to send — promote it to an " +
                "RFI first, then reply into the thread with the official PDF.");

        // Recipients are NOT resolved here — a reply inherits the original conversation's
        // participants from Graph, which is the point: the document lands in the existing thread.
        var model = await RequestDocumentBuilder.BuildAsync(context, command.RequestId, cancellationToken);
        if (model is null) throw new InvalidOperationException($"Request '{command.RequestId}' not found.");

        var pdf = RequestDocumentRenderer.Render(model);
        var tag = TriageCategories.ForRecord(await RequestTags.StemAsync(context, request, cancellationToken));

        var created = await graph.CreateReplyDraftAsync(
            new MailboxReplyDraftMessage(
                command.MailboxMessageId,
                PrepareRequestEmailDraftHandler.BuildCoverNote(model),
                new[] { new MailboxDraftAttachment(model.FileName, "application/pdf", pdf) },
                new[] { TriageCategories.Marker, tag, TriageCategories.Client }),
            cancellationToken);
        if (created is null)
            throw new InvalidOperationException(
                "The reply draft couldn't be created in the projects mailbox. The original email may " +
                "no longer be there, or the mailbox connection failed — check and try again.");

        // Audit (client-facing): the drafted reply, with its webLink, so it can be found in Outlook.
        await audit.WriteAsync(
            AuditEventType.DraftCreated,
            $"{model.TypeShort} {model.DisplayNumber} reply document drafted — awaiting review and send.",
            pathway: "Client",
            projectId: request.ProjectId,
            recordType: RecordType.Request,
            recordId: request.RequestId,
            recordReference: model.DisplayNumber,
            emailMessageId: created.Id,
            webLink: created.WebLink,
            cancellationToken: cancellationToken);

        // Same rule as the fresh-email draft: drafted means it's going out, so a Needs-action
        // request moves to Open (awaiting the correspondent's response) now (manually set back to
        // Needs action if the send is cancelled). Requests already past Needs action keep their
        // status — a re-draft never rewinds a lifecycle.
        if ((RequestStatus)request.Status == RequestStatus.NeedsAction)
        {
            request.Status = (int)RequestStatus.Open;
            await context.SaveChangesAsync(cancellationToken);
        }

        return new RequestEmailDraft(
            request.RequestId,
            created.Subject,
            created.To,
            created.WebLink,
            Cc: created.Cc);
    }
}
