using Jewel.JPMS.Api.Data;
using Jewel.JPMS.Api.Features.Requests.Recipients;
using Jewel.JPMS.Models;
using Microsoft.EntityFrameworkCore;

namespace Jewel.JPMS.Api.Features.Requests.Documents;

/// <summary>
/// Collates a <see cref="RequestDocumentModel"/> from the SQL source of truth. Pure read: it never
/// mutates state, so calling it on creation, on download, or on every resend always reflects the
/// request exactly as it currently stands (idempotent regeneration — nothing is persisted).
/// </summary>
public static class RequestDocumentBuilder
{
    public static async Task<RequestDocumentModel?> BuildAsync(
        JpmsContext context, string requestId, CancellationToken ct,
        RequestRecipientSet? resolvedRecipients = null)
    {
        var request = await context.Requests
            .FirstOrDefaultAsync(r => r.RequestId == requestId, ct);
        if (request is null)
            return null;

        var project = await context.Projects
            .FirstOrDefaultAsync(p => p.ProjectId == request.ProjectId, ct);

        // Recipients come from the shared resolver (request party → project party → project
        // profile), so the document's issued-to block always matches what an actual send would
        // address. Only To and Cc reach the document — Bcc stays off every client-facing surface.
        // Callers that already resolved (the worker send, the draft) pass their set in so a single
        // send never resolves twice.
        var recipientSet = resolvedRecipients
            ?? await RequestRecipientResolver.ResolveAsync(context, request, ct);
        var recipients = recipientSet.To.Concat(recipientSet.Cc)
            .Select(r => new RequestDocumentRecipient(
                r.Name, r.Email, r.RoleLabel ?? "Contact", r.Organisation, r.Routing))
            .ToList();

        // The document deliberately carries NO activity/correspondence history: it is the formal
        // request sheet only. Conversation (in-app messages and tagged emails) lives on the request
        // page and in the mailbox thread, never on the issued PDF.

        // The official document's itemised queries, in display order.
        var items = await context.RequestItems
            .Where(i => i.RequestId == requestId)
            .OrderBy(i => i.Position)
            .Select(i => new RequestDocumentItem(i.Position, i.DrawingRef, i.MemberArea, i.Query, i.Response))
            .ToListAsync(ct);

        var kind = (RequestType)request.Kind;
        var status = (RequestStatus)request.Status;

        return new RequestDocumentModel(
            RequestId: request.RequestId,
            DisplayNumber: request.Number > 0 ? $"REQ-{request.Number:0000}" : "",
            TypeShort: kind.DisplayName(),
            TypeLong: kind.LongName(),
            Title: request.Title,
            Description: request.Description,
            StatusLabel: StatusLabel(status),
            ProjectName: project?.Name ?? "(unknown project)",
            ProjectReference: project?.Reference ?? request.ProjectId,
            ClientName: project?.ClientName ?? "",
            RaisedByEmail: request.RaisedByEmail,
            RaisedAt: request.RaisedAt,
            IssuedAt: request.IssuedAt,
            ResponseDue: request.ResponseDue,
            DrawingRef: request.DrawingRef,
            RelatedDrawingSpec: request.RelatedDrawingSpec,
            Value: request.Value,
            ImpliesVariation: request.ImpliesVariation,
            ClientNotes: request.ClientNotes,
            ResponseText: request.ResponseText,
            RespondedByEmail: request.RespondedByEmail,
            RespondedAt: request.RespondedAt,
            Recipients: recipients,
            GeneratedAt: DateTimeOffset.UtcNow,
            Reference: request.Reference,
            BasisOfQueries: request.BasisOfQueries,
            ResponseActionRequired: request.ResponseActionRequired,
            ImpactIfLate: request.ImpactIfLate,
            Items: items);
    }

    private static string StatusLabel(RequestStatus status) => status.DisplayName();
}
