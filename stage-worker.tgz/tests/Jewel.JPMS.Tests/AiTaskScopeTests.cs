using System.Text.Json;
using Jewel.JPMS.Contracts.Ai;
using Jewel.JPMS.Models;
using Xunit;

namespace Jewel.JPMS.Tests;

// The contract between the assistant panel, the server prompt and a task dialog.
//
// ModalCatalog is the registry that decides which dialogs the assistant may fill in at all
// (docs/ai/00-agent-architecture.md §5). Registering one is an explicit grant, so the things worth
// pinning are: that the grant is role-filtered, and that the schema handed to the model actually
// describes the form the browser will merge into. A field name that drifts between the two does not
// fail loudly — the model sends "summary", the dialog ignores it, and the user watches an assistant
// claim to have filled in a form that never changed.
public sealed class AiTaskScopeTests
{
    [Fact]
    public void AiScope_taskIsOptional_soThePlainConstructionSitesKeepWorking()
    {
        // The chat panel builds this shape for every non-task turn, and the server reads Task to
        // decide whether the "you can only read and navigate" rule is in force. If the parameter
        // ever stopped being defaulted, every general conversation would need a null threaded
        // through it — and a required parameter is exactly the kind of thing somebody "fixes" by
        // passing an empty task.
        var scope = new AiScope("proj-1", "/projects/proj-1/requests", "Requests");

        Assert.Null(scope.Task);
    }

    [Fact]
    public void VariationDraft_isRegistered_andOnlyForTheRolesThatCanRaiseAVariation()
    {
        var modal = ModalCatalog.Find("variation_draft");
        Assert.NotNull(modal);

        // Whoever may raise a variation may have the assistant draft it. Anyone else must not even
        // be told the dialog exists.
        Assert.True(ModalCatalog.CanOpen(modal!, new[] { Role.ProjectManager }));
        Assert.True(ModalCatalog.CanOpen(modal!, new[] { Role.QuantitySurveyor }));
        Assert.True(ModalCatalog.CanOpen(modal!, new[] { Role.ManagingDirector }));
        Assert.False(ModalCatalog.CanOpen(modal!, new[] { Role.SiteManager }));
        Assert.False(ModalCatalog.CanOpen(modal!, new[] { Role.Subcontractor }));

        // The Finance Director HAS the assistant but must not have this dialog: the API's
        // CreateVoqFromRfq gate (VariationRoles.AllowedToManageVariations) does not include them, so
        // offering it would end in a 403 on the button after a paid read of the whole email thread.
        Assert.False(ModalCatalog.CanOpen(modal!, new[] { Role.FinanceDirector }));

        // Admin passes every gate in this system (SignedInUserResolver grants them all roles), and
        // this registry must not be the one place that is not true.
        Assert.True(ModalCatalog.CanOpen(modal!, new[] { Role.Admin }));
    }

    [Fact]
    public void Find_isCaseInsensitiveAndSafeOnRubbish()
    {
        // The key arrives from the model on one path and from an untrusted client scope on another.
        Assert.NotNull(ModalCatalog.Find("VARIATION_DRAFT"));
        Assert.Null(ModalCatalog.Find("variation_quote"));
        Assert.Null(ModalCatalog.Find(""));
        Assert.Null(ModalCatalog.Find(null));
    }

    [Fact]
    public void SchemaFor_describesEveryFieldTheDialogMergesBack()
    {
        var json = JsonSerializer.Serialize(ModalCatalog.SchemaFor(ModalCatalog.VariationDraft));
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;

        Assert.Equal("object", root.GetProperty("type").GetString());

        // These names are the contract with ProjectRequestDetail.SerialiseDraft /
        // ApplyAssistantDraft. Renaming one on either side alone is a silent no-op.
        var properties = root.GetProperty("properties");
        foreach (var field in new[] { "title", "description", "estimatedValue", "trade", "lines" })
        {
            Assert.True(properties.TryGetProperty(field, out var declared), $"missing field: {field}");
            Assert.False(
                string.IsNullOrWhiteSpace(declared.GetProperty("description").GetString()),
                $"{field} has no description — the description IS the model's instruction for it");
        }

        // Title is the only field the dialog refuses to be raised without, so it is the only one
        // the model is told is required.
        var required = root.GetProperty("required").EnumerateArray().Select(item => item.GetString()).ToList();
        Assert.Equal(new[] { "title" }, required);
    }

    [Fact]
    public void SchemaFor_givesScopeLinesAnItemShape_includingTheCostCode()
    {
        var json = JsonSerializer.Serialize(ModalCatalog.SchemaFor(ModalCatalog.VariationDraft));
        using var document = JsonDocument.Parse(json);

        var lines = document.RootElement.GetProperty("properties").GetProperty("lines");
        Assert.Equal("array", lines.GetProperty("type").GetString());

        // Without an items schema the model is guessing at the shape of a tender line — and a made-up
        // cost code is a real committed value landing on the wrong cost centre.
        var item = lines.GetProperty("items").GetProperty("properties");
        foreach (var field in new[] { "description", "unit", "quantity", "trade", "costCode" })
            Assert.True(item.TryGetProperty(field, out _), $"missing line field: {field}");
    }

    [Fact]
    public void EveryRegisteredModal_hasARouteWithBothSubstitutions()
    {
        // ChatPanel.ApplyOpenModal substitutes exactly these two and navigates to the result. A
        // template missing one would send the user to a literal "{record}" URL.
        foreach (var modal in ModalCatalog.All)
        {
            Assert.Contains("{project}", modal.RouteTemplate);
            Assert.Contains("{record}", modal.RouteTemplate);
            Assert.StartsWith("/", modal.RouteTemplate);
        }
    }
}
